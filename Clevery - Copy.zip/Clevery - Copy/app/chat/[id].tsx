import React, { useState, useEffect, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    FlatList,
    Platform,
    Image,
    ActivityIndicator,
    Keyboard,
    Animated
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
    ArrowLeft,
    Send,
    Phone,
    Video,
    MoreVertical,
    FileText,
    Smile,
    Image as ImageIcon,
    Camera
} from 'lucide-react-native';
import { Colors } from '../../constants/Colors';
import { telegram } from '../../lib/telegram';
import { fetchMessages, sendMessage as sendTelegramMessage, subscribeToMessages, markAsRead, Message } from '../../lib/telegram-chat';

export default function ChatScreen() {
    const { id, name, type, avatar, members } = useLocalSearchParams();
    const router = useRouter();
    const insets = useSafeAreaInsets();
    const [message, setMessage] = useState('');
    const [messages, setMessages] = useState<Message[]>([]);
    const flatListRef = useRef<FlatList>(null);
    const [loading, setLoading] = useState(true);
    const [sending, setSending] = useState(false);
    const keyboardHeight = useRef(new Animated.Value(0)).current;
    const channelRef = useRef<any>(null);
    const [currentUserId, setCurrentUserId] = useState<string | null>(null);

    // Get current user
    useEffect(() => {
        telegram.getMe().then((me: any) => {
            setCurrentUserId(me?.id?.toString() || me?.id || null);
        });
    }, []);

    // Fetch initial messages
    useEffect(() => {
        if (!id) return;

        const loadMessages = async () => {
            setLoading(true);
            const msgs = await fetchMessages(id as string);
            setMessages(msgs);
            setLoading(false);

            // Mark as read
            await markAsRead(id as string);
        };

        loadMessages();
    }, [id]);

    // Subscribe to real-time messages
    useEffect(() => {
        if (!id || !currentUserId) return;

        const channel = subscribeToMessages(id as string, (newMessage) => {
            // Only add if it's not already in the list (avoid duplicates from optimistic updates)
            setMessages(prev => {
                const exists = prev.some(m => m.id === newMessage.id);
                if (exists) return prev;
                return [...prev, newMessage];
            });

            // Auto-scroll to bottom
            setTimeout(() => {
                flatListRef.current?.scrollToEnd({ animated: true });
            }, 100);
        });

        channelRef.current = channel;

        return () => {
            channel.unsubscribe();
        };
    }, [id, currentUserId]);

    // Keyboard listeners
    useEffect(() => {
        const keyboardWillShow = Keyboard.addListener(
            Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow',
            (e) => {
                Animated.timing(keyboardHeight, {
                    duration: e.duration || 250,
                    toValue: e.endCoordinates.height - insets.bottom,
                    useNativeDriver: false,
                }).start();
            }
        );

        const keyboardWillHide = Keyboard.addListener(
            Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide',
            (e) => {
                Animated.timing(keyboardHeight, {
                    duration: e.duration || 250,
                    toValue: 0,
                    useNativeDriver: false,
                }).start();
            }
        );

        return () => {
            keyboardWillShow.remove();
            keyboardWillHide.remove();
        };
    }, [insets.bottom]);

    const handleSend = async () => {
        if (!message.trim() || !id || sending) return;

        setSending(true);
        const messageText = message;
        setMessage(''); // Clear input immediately
        Keyboard.dismiss(); // Dismiss keyboard

        // Optimistically add message to UI immediately
        const tempMessage: Message = {
            id: `temp-${Date.now()}`,
            chat_id: id as string,
            sender_id: currentUserId || '',
            content: messageText,
            is_ai: false,
            created_at: new Date().toISOString(),
        };

        setMessages(prev => [...prev, tempMessage]);

        // Scroll to bottom
        setTimeout(() => {
            flatListRef.current?.scrollToEnd({ animated: true });
        }, 100);

        // Send to server
        const sentMessage = await sendTelegramMessage(id as string, messageText);

        if (!sentMessage) {
            // Remove temp message and restore input if failed
            setMessages(prev => prev.filter(m => m.id !== tempMessage.id));
            setMessage(messageText);
            alert('Failed to send message');
        } else {
            // Replace temp message with real one
            setMessages(prev => prev.map(m => m.id === tempMessage.id ? sentMessage : m));
        }

        setSending(false);
    };

    const renderMessage = ({ item }: { item: Message }) => {
        const isMyMessage = item.sender_id === currentUserId;

        if (isMyMessage) {
            return (
                <View style={[styles.messageBubble, styles.myMessage]}>
                    <Text style={[styles.messageText, styles.myMessageText]}>{item.content}</Text>
                    <Text style={[styles.messageTime, styles.myMessageTime]}>
                        {new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </Text>
                </View>
            );
        }

        return (
            <View style={styles.theirMessageContainer}>
                {/* Avatar for received messages */}
                <Image
                    source={{ uri: item.sender?.avatar_url || 'https://i.pravatar.cc/150' }}
                    style={styles.msgAvatar}
                />
                <View>
                    {/* Name only for Class Groups */}
                    {type === 'class' && (
                        <Text style={styles.senderName}>{item.sender?.username || 'User'}</Text>
                    )}
                    <View style={[styles.messageBubble, styles.theirMessage]}>
                        <Text style={[styles.messageText, styles.theirMessageText]}>{item.content}</Text>
                        <Text style={[styles.messageTime, styles.theirMessageTime]}>
                            {new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </Text>
                    </View>
                </View>
            </View>
        );
    };

    return (
        <View style={styles.container}>
            {/* Background Gradient & Status Bar Protector */}
            <LinearGradient
                colors={['#E0F2FE', '#fff']}
                style={{ height: insets.top + 70, position: 'absolute', top: 0, left: 0, right: 0, zIndex: 0 }}
            />
            <View style={{ height: insets.top, zIndex: 10 }} />

            {/* Header */}
            <View style={styles.header}>
                <View style={styles.headerLeft}>
                    <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                        <ArrowLeft size={24} color={Colors.text} />
                    </TouchableOpacity>

                    <Image
                        source={{ uri: (avatar as string) || 'https://i.pravatar.cc/150' }}
                        style={styles.headerAvatar}
                    />

                    <View style={styles.headerInfo}>
                        <Text style={styles.headerTitle} numberOfLines={1}>{name || 'Chat'}</Text>
                        <Text style={styles.headerSubtitle} numberOfLines={1}>
                            {type === 'class' ? `${members || '24'} members` : 'Online'}
                        </Text>
                    </View>
                </View>

                <View style={styles.headerRight}>
                    <TouchableOpacity style={styles.headerIcon}>
                        <Phone size={22} color={Colors.primary} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.headerIcon}>
                        <Video size={22} color={Colors.primary} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.headerIcon}>
                        <MoreVertical size={22} color={Colors.textSecondary} />
                    </TouchableOpacity>
                </View>
            </View>

            {/* Messages List */}
            <FlatList
                ref={flatListRef}
                data={messages}
                keyExtractor={item => item.id}
                renderItem={renderMessage}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
            />

            {/* Input Area */}
            <Animated.View style={[styles.inputWrapper, { marginBottom: keyboardHeight }]}>
                {/* Attachment Icons Row */}
                <View style={styles.attachmentRow}>
                    <TouchableOpacity style={styles.attachIcon}>
                        <Camera size={22} color={Colors.textSecondary} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.attachIcon}>
                        <ImageIcon size={22} color={Colors.textSecondary} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.attachIcon}>
                        <FileText size={22} color={Colors.textSecondary} />
                    </TouchableOpacity>
                </View>

                {/* Input Bar Row */}
                <View style={styles.inputRow}>
                    <View style={styles.inputContainer}>
                        <TextInput
                            style={styles.input}
                            placeholder="Type a message..."
                            value={message}
                            onChangeText={setMessage}
                            multiline
                        />
                    </View>

                    <TouchableOpacity
                        onPress={handleSend}
                        style={[styles.sendButton, !message.trim() && styles.sendButtonDisabled]}
                        disabled={!message.trim()}
                    >
                        <Send size={20} color="#fff" />
                    </TouchableOpacity>
                </View>
            </Animated.View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingBottom: 15,
        paddingTop: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
        backgroundColor: 'transparent', // Transparent to show gradient
        zIndex: 1,
    },
    headerLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1,
        marginRight: 10,
    },
    backButton: {
        marginRight: 8,
        padding: 4,
    },
    headerAvatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
        marginRight: 10,
        backgroundColor: '#fff' // White bg to pop against gradient
    },
    headerInfo: {
        flex: 1,
        justifyContent: 'center',
    },
    headerTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.text,
    },
    headerSubtitle: {
        fontSize: 12,
        color: Colors.textSecondary,
        fontWeight: '500',
        marginTop: 1,
    },
    headerRight: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4
    },
    headerIcon: {
        padding: 8,
    },
    listContent: {
        paddingHorizontal: 16,
        paddingVertical: 20,
        gap: 12, // Gap between messages
    },
    theirMessageContainer: {
        flexDirection: 'row',
        alignItems: 'flex-end',
        marginBottom: 2,
    },
    msgAvatar: {
        width: 28,
        height: 28,
        borderRadius: 14,
        marginRight: 8,
        marginBottom: 4,
    },
    senderName: {
        fontSize: 11,
        color: Colors.textSecondary,
        marginLeft: 4,
        marginBottom: 2,
    },
    messageBubble: {
        maxWidth: '80%',
        paddingHorizontal: 16,
        paddingVertical: 12,
        borderRadius: 20,
        marginBottom: 2,
    },
    myMessage: {
        alignSelf: 'flex-end',
        backgroundColor: Colors.primary,
        borderBottomRightRadius: 4,
    },
    theirMessage: {
        alignSelf: 'flex-start',
        backgroundColor: '#F3F4F6',
        borderBottomLeftRadius: 4,
    },
    messageText: {
        fontSize: 15,
        lineHeight: 22,
    },
    myMessageText: {
        color: '#fff',
    },
    theirMessageText: {
        color: Colors.text,
    },
    messageTime: {
        fontSize: 10,
        marginTop: 4,
        alignSelf: 'flex-end',
        opacity: 0.7,
    },
    myMessageTime: {
        color: '#E0E7FF',
    },
    theirMessageTime: {
        color: Colors.textSecondary,
    },
    inputWrapper: {
        paddingHorizontal: 16,
        paddingTop: 8,
        paddingBottom: Platform.OS === 'ios' ? 10 : 10,
        backgroundColor: '#fff',
        borderTopWidth: 1,
        borderTopColor: '#f1f5f9',
    },
    attachmentRow: {
        flexDirection: 'row',
        marginBottom: 10, // Space between icons and input
        gap: 20, // More space
        paddingLeft: 4,
    },
    attachIcon: {
        padding: 4,
    },
    inputRow: {
        flexDirection: 'row',
        alignItems: 'flex-end',
        gap: 10,
    },
    inputContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#F3F4F6',
        borderRadius: 24,
        minHeight: 44,
    },
    input: {
        flex: 1,
        fontSize: 16,
        color: Colors.text,
        maxHeight: 100,
        paddingRight: 8,
        paddingTop: Platform.OS === 'ios' ? 0 : 0,
        paddingHorizontal: 16, // Added padding here
        paddingVertical: 8, // Added padding here
    },
    emojiButton: {
        padding: 4,
    },
    sendButton: {
        backgroundColor: Colors.primary,
        width: 44,
        height: 44,
        borderRadius: 22,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 1,
    },
    sendButtonDisabled: {
        backgroundColor: '#D1D5DB',
    },
});
