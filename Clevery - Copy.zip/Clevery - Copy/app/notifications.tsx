import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    FlatList,
    Image,
    ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
    ArrowLeft,
    Check,
    X,
    Users,
} from 'lucide-react-native';
import { Colors } from '../constants/Colors';
import { useRouter } from 'expo-router';
import {
    fetchClassmateRequests,
    acceptClassmateRequest,
    rejectClassmateRequest,
    Classmate
} from '../lib/telegram-classmates';
import {
    fetchClassInvites,
    acceptClassInvite,
    rejectClassInvite,
    ClassInvite
} from '../lib/telegram-classes';

export default function NotificationsScreen() {
    const insets = useSafeAreaInsets();
    const router = useRouter();
    const [classmateRequests, setClassmateRequests] = useState<Classmate[]>([]);
    const [classInvites, setClassInvites] = useState<ClassInvite[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadNotifications();
    }, []);

    const loadNotifications = async () => {
        setLoading(true);
        const [requests, invites] = await Promise.all([
            fetchClassmateRequests(),
            fetchClassInvites(),
        ]);
        setClassmateRequests(requests);
        setClassInvites(invites);
        setLoading(false);
    };

    const handleAccept = async (id: string, type: 'classmate' | 'class') => {
        if (type === 'classmate') {
            const success = await acceptClassmateRequest(id);
            if (success) {
                setClassmateRequests(prev => prev.filter(r => r.id !== id));
            }
        } else {
            const success = await acceptClassInvite(id);
            if (success) {
                setClassInvites(prev => prev.filter(i => i.id !== id));
            }
        }
    };

    const handleReject = async (id: string, type: 'classmate' | 'class') => {
        if (type === 'classmate') {
            const success = await rejectClassmateRequest(id);
            if (success) {
                setClassmateRequests(prev => prev.filter(r => r.id !== id));
            }
        } else {
            const success = await rejectClassInvite(id);
            if (success) {
                setClassInvites(prev => prev.filter(i => i.id !== id));
            }
        }
    };

    const renderClassmateRequest = ({ item }: { item: Classmate }) => (
        <View style={styles.requestCard}>
            <Image source={{ uri: item.avatar_url || 'https://i.pravatar.cc/150' }} style={styles.avatar} />
            <View style={styles.requestInfo}>
                <Text style={styles.requestName}>{item.username || 'User'}</Text>
                <Text style={styles.mutualClassmates}>Wants to connect</Text>
            </View>
            <View style={styles.actions}>
                <TouchableOpacity
                    style={[styles.actionButton, styles.acceptButton]}
                    onPress={() => handleAccept(item.id, 'classmate')}
                >
                    <Check size={20} color="#fff" />
                </TouchableOpacity>
                <TouchableOpacity
                    style={[styles.actionButton, styles.rejectButton]}
                    onPress={() => handleReject(item.id, 'classmate')}
                >
                    <X size={20} color="#fff" />
                </TouchableOpacity>
            </View>
        </View>
    );

    const renderClassInvite = ({ item }: { item: ClassInvite }) => (
        <View style={styles.requestCard}>
            <View style={[styles.avatar, styles.classAvatar]}>
                <Users size={24} color={Colors.primary} />
            </View>
            <View style={styles.requestInfo}>
                <Text style={styles.requestName}>{item.class?.name || 'Class'}</Text>
                <Text style={styles.mutualClassmates}>Invited by {item.inviter?.username}</Text>
            </View>
            <View style={styles.actions}>
                <TouchableOpacity
                    style={[styles.actionButton, styles.acceptButton]}
                    onPress={() => handleAccept(item.id, 'class')}
                >
                    <Check size={20} color="#fff" />
                </TouchableOpacity>
                <TouchableOpacity
                    style={[styles.actionButton, styles.rejectButton]}
                    onPress={() => handleReject(item.id, 'class')}
                >
                    <X size={20} color="#fff" />
                </TouchableOpacity>
            </View>
        </View>
    );

    return (
        <View style={styles.container}>
            {/* Gradient Background */}
            <LinearGradient
                colors={['#E0F2FE', '#fff']}
                style={{ height: insets.top + 60, position: 'absolute', top: 0, left: 0, right: 0, zIndex: 0 }}
            />
            <View style={{ height: insets.top, zIndex: 10 }} />

            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                    <ArrowLeft size={24} color={Colors.text} />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Notifications</Text>
                <View style={{ width: 40 }} />
            </View>

            {loading ? (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <ActivityIndicator size="large" color={Colors.primary} />
                </View>
            ) : (
                <FlatList
                    data={[...classmateRequests, ...classInvites] as any}
                    keyExtractor={item => item.id}
                    renderItem={({ item }) => {
                        if ('classmate_id' in item) {
                            return renderClassmateRequest({ item });
                        } else {
                            return renderClassInvite({ item });
                        }
                    }}
                    contentContainerStyle={styles.listContent}
                    ListEmptyComponent={
                        <View style={{ alignItems: 'center', marginTop: 50 }}>
                            <Text style={{ color: Colors.textSecondary, fontSize: 16 }}>
                                No pending notifications
                            </Text>
                        </View>
                    }
                    ListHeaderComponent={
                        classmateRequests.length > 0 ? (
                            <View>
                                <Text style={styles.sectionTitle}>Classmate Requests</Text>
                            </View>
                        ) : null
                    }
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingBottom: 15,
        paddingTop: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
        backgroundColor: 'transparent',
        zIndex: 1,
    },
    backButton: {
        padding: 4,
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: '700',
        color: Colors.text,
    },
    listContent: {
        paddingHorizontal: 20,
        paddingTop: 20,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.text,
        marginBottom: 15,
    },
    requestCard: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
    },
    avatar: {
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: '#f1f5f9',
    },
    classAvatar: {
        backgroundColor: Colors.primary + '20',
        justifyContent: 'center',
        alignItems: 'center',
    },
    requestInfo: {
        flex: 1,
        marginLeft: 12,
    },
    requestName: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.text,
    },
    mutualClassmates: {
        fontSize: 13,
        color: Colors.textSecondary,
        marginTop: 2,
    },
    actions: {
        flexDirection: 'row',
        gap: 8,
    },
    actionButton: {
        width: 40,
        height: 40,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    acceptButton: {
        backgroundColor: '#10b981',
    },
    rejectButton: {
        backgroundColor: '#ef4444',
    },
});
