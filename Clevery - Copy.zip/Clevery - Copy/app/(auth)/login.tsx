import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    KeyboardAvoidingView,
    Platform,
    Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Phone, Hash, ArrowRight, BrainCircuit, User, ArrowLeft } from 'lucide-react-native';
import { Colors } from '../../constants/Colors';
import { useRouter } from 'expo-router';
import { telegram } from '../../lib/telegram';

export default function LoginScreen() {
    const [phoneNumber, setPhoneNumber] = useState('');
    const [code, setCode] = useState('');
    const [phoneCodeHash, setPhoneCodeHash] = useState('');
    const [loading, setLoading] = useState(false);
    const [step, setStep] = useState<'phone' | 'code'>('phone');
    const router = useRouter();

    const handleSendCode = async () => {
        if (!phoneNumber) {
            alert('Please enter your phone number');
            return;
        }
        setLoading(true);
        try {
            const result = await telegram.sendCode(phoneNumber);
            setPhoneCodeHash(result.phoneCodeHash);
            setStep('code');
        } catch (error: any) {
            alert(error.message || 'Failed to send code');
        } finally {
            setLoading(false);
        }
    };

    const handleVerifyCode = async () => {
        if (!code) {
            alert('Please enter the verification code');
            return;
        }
        setLoading(true);
        try {
            const user: any = await telegram.signIn(phoneNumber, phoneCodeHash, code);
            
            // Join community group
            const communityId = process.env.EXPO_PUBLIC_TELEGRAM_COMMUNITY_CHAT_ID || '-1003708310474';
            await telegram.joinChannel(communityId);
            
            // Check if user exists in Supabase
            const { getUserProfile } = await import('../../lib/supabase');
            const profile = await getUserProfile(user.id.toString());
            
            if (!profile) {
                // New user - go to onboarding
                router.replace('/(auth)/onboarding');
            } else {
                // Return user - refresh daily stars and go to tabs
                const { grantDailyStars } = await import('../../lib/supabase');
                await grantDailyStars(user.id.toString());
                router.replace('/(tabs)');
            }
        } catch (error: any) {
            alert(error.message || 'Failed to verify code');
        } finally {
            setLoading(false);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={styles.keyboardView}
            >
                <View style={styles.content}>
                    {/* Logo Section */}
                    <View style={styles.logoContainer}>
                        <View style={styles.logoIcon}>
                            <BrainCircuit size={40} color="#fff" />
                        </View>
                        <Text style={styles.logoText}>Clevery</Text>
                        <Text style={styles.logoTagline}>Where Intelligence Meets Education</Text>
                    </View>

                    {/* Form Section */}
                    <View style={styles.form}>
                        <Text style={styles.welcomeText}>
                            {step === 'phone' ? 'Welcome!' : 'Verify Code'}
                        </Text>
                        <Text style={styles.subtitleText}>
                            {step === 'phone' 
                                ? 'Sign in with your Telegram phone number.' 
                                : `Enter the code sent to ${phoneNumber}`}
                        </Text>

                        {step === 'phone' ? (
                            <View style={styles.inputGroup}>
                                <Text style={styles.label}>Phone Number</Text>
                                <View style={styles.inputWrapper}>
                                    <Phone size={20} color={Colors.textSecondary} style={styles.inputIcon} />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="+1234567890"
                                        value={phoneNumber}
                                        onChangeText={setPhoneNumber}
                                        keyboardType="phone-pad"
                                        autoComplete="tel"
                                    />
                                </View>
                            </View>
                        ) : (
                            <View style={styles.inputGroup}>
                                <Text style={styles.label}>Verification Code</Text>
                                <View style={styles.inputWrapper}>
                                    <Hash size={20} color={Colors.textSecondary} style={styles.inputIcon} />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="12345"
                                        value={code}
                                        onChangeText={setCode}
                                        keyboardType="number-pad"
                                    />
                                </View>
                            </View>
                        )}

                        <TouchableOpacity
                            style={[styles.loginButton, loading && styles.disabledButton]}
                            onPress={step === 'phone' ? handleSendCode : handleVerifyCode}
                            disabled={loading}
                        >
                            <Text style={styles.loginButtonText}>
                                {step === 'phone' ? 'Send Code' : 'Verify'}
                            </Text>
                            <ArrowRight size={20} color="#fff" />
                        </TouchableOpacity>

                        {step === 'code' && (
                            <TouchableOpacity 
                                style={styles.backButton} 
                                onPress={() => setStep('phone')}
                                disabled={loading}
                            >
                                <ArrowLeft size={16} color={Colors.primary} />
                                <Text style={styles.backButtonText}>Change Phone Number</Text>
                            </TouchableOpacity>
                        )}
                    </View>
                </View>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    keyboardView: {
        flex: 1,
    },
    content: {
        flex: 1,
        paddingHorizontal: 30,
        justifyContent: 'center',
    },
    logoContainer: {
        alignItems: 'center',
        marginBottom: 50,
    },
    logoIcon: {
        width: 80,
        height: 80,
        backgroundColor: Colors.primary,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 15,
        elevation: 10,
        shadowColor: Colors.primary,
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.3,
        shadowRadius: 15,
    },
    logoText: {
        fontSize: 32,
        fontWeight: 'bold',
        color: Colors.text,
    },
    logoTagline: {
        fontSize: 14,
        color: Colors.textSecondary,
        marginTop: 5,
    },
    form: {
        gap: 20,
    },
    welcomeText: {
        fontSize: 28,
        fontWeight: 'bold',
        color: Colors.text,
    },
    subtitleText: {
        fontSize: 16,
        color: Colors.textSecondary,
        marginBottom: 10,
    },
    inputGroup: {
        gap: 8,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.text,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f8fafc',
        borderRadius: 15,
        paddingHorizontal: 15,
        height: 55,
        borderWidth: 1,
        borderColor: '#e2e8f0',
    },
    inputIcon: {
        marginRight: 12,
    },
    input: {
        flex: 1,
        fontSize: 16,
        color: Colors.text,
    },
    loginButton: {
        backgroundColor: Colors.primary,
        height: 55,
        borderRadius: 15,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 10,
        marginTop: 10,
        elevation: 5,
        shadowColor: Colors.primary,
        shadowOffset: { width: 0, height: 5 },
        shadowOpacity: 0.2,
        shadowRadius: 10,
    },
    disabledButton: {
        backgroundColor: '#cbd5e1',
    },
    loginButtonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
    backButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        marginTop: 10,
        padding: 10,
    },
    backButtonText: {
        color: Colors.primary,
        fontSize: 16,
        fontWeight: '600',
    },
});
