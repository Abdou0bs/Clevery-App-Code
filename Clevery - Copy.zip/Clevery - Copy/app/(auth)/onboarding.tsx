import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    ScrollView,
    KeyboardAvoidingView,
    Platform,
    ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { 
    User, 
    Globe, 
    Languages, 
    GraduationCap, 
    ArrowRight, 
    Check,
    ChevronLeft
} from 'lucide-react-native';
import { Colors } from '../../constants/Colors';
import { useRouter } from 'expo-router';
import { telegram } from '../../lib/telegram';
import { updateUserProfile } from '../../lib/supabase';

const ACADEMIC_LEVELS = [
    'Middle School',
    'High School',
    'Undergraduate',
    'Postgraduate',
    'Professional',
    'Other'
];

const LANGUAGES = [
    'Arabic',
    'English',
    'French',
    'Spanish',
    'German',
    'Other'
];

export default function OnboardingScreen() {
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(false);
    const [telegramUser, setTelegramUser] = useState<any>(null);
    const router = useRouter();

    // Form State
    const [username, setUsername] = useState('');
    const [country, setCountry] = useState('');
    const [language, setLanguage] = useState('Arabic');
    const [academicLevel, setAcademicLevel] = useState('High School');

    useEffect(() => {
        const fetchMe = async () => {
            try {
                const me = await telegram.getMe();
                if (me) {
                    setTelegramUser(me);
                    // Don't pre-fill username anymore, Clevery unique username is required.
                }
            } catch (e) {
                console.error('Failed to fetch me', e);
            }
        };
        fetchMe();
    }, []);

    const handleComplete = async () => {
        if (!username || !country) {
            alert('Please fill in all required fields');
            return;
        }

        setLoading(true);
        try {
            if (!telegramUser) throw new Error('Telegram session not found');
            
            await updateUserProfile(telegramUser.id.toString(), {
                username,
                country,
                language,
                academic_level: academicLevel,
                stars_tokens: 5, // Default initial stars
                credits: 50, // Welcome credits
                created_at: new Date().toISOString(),
                last_login: new Date().toISOString(),
            });

            router.replace('/(tabs)');
        } catch (error: any) {
            alert(error.message || 'Failed to save profile');
        } finally {
            setLoading(false);
        }
    };

    const nextStep = () => {
        if (step === 1 && (!username || !country)) {
            alert('Please fill in your name and country');
            return;
        }
        if (step < 2) setStep(step + 1);
        else handleComplete();
    };

    const prevStep = () => {
        if (step > 1) setStep(step - 1);
    };

    const renderStep1 = () => (
        <View style={styles.stepContainer}>
            <Text style={styles.title}>Basic Info</Text>
            <Text style={styles.subtitle}>Let's get to know you better</Text>

            <View style={styles.inputGroup}>
                <Text style={styles.label}>Choose Username</Text>
                <View style={styles.inputWrapper}>
                    <User size={20} color={Colors.textSecondary} style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="Your username"
                        value={username}
                        onChangeText={setUsername}
                    />
                </View>
            </View>

            <View style={styles.inputGroup}>
                <Text style={styles.label}>Country</Text>
                <View style={styles.inputWrapper}>
                    <Globe size={20} color={Colors.textSecondary} style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="Where are you from?"
                        value={country}
                        onChangeText={setCountry}
                    />
                </View>
            </View>
        </View>
    );

    const renderStep2 = () => (
        <View style={styles.stepContainer}>
            <Text style={styles.title}>Preferences</Text>
            <Text style={styles.subtitle}>Customize your learning experience</Text>

            <Text style={styles.label}>Preferred Language</Text>
            <View style={styles.optionsGrid}>
                {LANGUAGES.map((lang) => (
                    <TouchableOpacity
                        key={lang}
                        style={[styles.optionCard, language === lang && styles.optionCardSelected]}
                        onPress={() => setLanguage(lang)}
                    >
                        <Text style={[styles.optionText, language === lang && styles.optionTextSelected]}>
                            {lang}
                        </Text>
                        {language === lang && <Check size={16} color="#fff" />}
                    </TouchableOpacity>
                ))}
            </View>

            <Text style={[styles.label, { marginTop: 20 }]}>Academic Level</Text>
            <ScrollView showsVerticalScrollIndicator={false} style={{ maxHeight: 250 }}>
                {ACADEMIC_LEVELS.map((level) => (
                    <TouchableOpacity
                        key={level}
                        style={[styles.levelCard, academicLevel === level && styles.levelCardSelected]}
                        onPress={() => setAcademicLevel(level)}
                    >
                        <GraduationCap 
                            size={20} 
                            color={academicLevel === level ? "#fff" : Colors.textSecondary} 
                        />
                        <Text style={[styles.levelText, academicLevel === level && styles.levelTextSelected]}>
                            {level}
                        </Text>
                    </TouchableOpacity>
                ))}
            </ScrollView>
        </View>
    );

    return (
        <SafeAreaView style={styles.container}>
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={{ flex: 1 }}
            >
                <View style={styles.header}>
                    {step > 1 ? (
                        <TouchableOpacity style={styles.backButton} onPress={prevStep}>
                            <ChevronLeft size={24} color={Colors.text} />
                        </TouchableOpacity>
                    ) : (
                        <View style={{ width: 44 }} />
                    )}
                    <View style={styles.progressContainer}>
                        <View style={[styles.progressBar, { width: `${(step / 2) * 100}%` }]} />
                    </View>
                    <View style={{ width: 44 }} />
                </View>

                <ScrollView contentContainerStyle={styles.scrollContent}>
                    {step === 1 ? renderStep1() : renderStep2()}
                </ScrollView>

                <View style={styles.footer}>
                    <TouchableOpacity
                        style={[styles.nextButton, loading && styles.disabledButton]}
                        onPress={nextStep}
                        disabled={loading}
                    >
                        {loading ? (
                            <ActivityIndicator color="#fff" />
                        ) : (
                            <>
                                <Text style={styles.nextButtonText}>
                                    {step === 2 ? 'Complete' : 'Continue'}
                                </Text>
                                <ArrowRight size={20} color="#fff" />
                            </>
                        )}
                    </TouchableOpacity>
                </View>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 15,
        paddingVertical: 10,
        justifyContent: 'space-between',
    },
    backButton: {
        padding: 5,
    },
    progressContainer: {
        flex: 1,
        height: 6,
        backgroundColor: '#f1f5f9',
        borderRadius: 3,
        marginHorizontal: 15,
        overflow: 'hidden',
    },
    progressBar: {
        height: '100%',
        backgroundColor: Colors.primary,
    },
    scrollContent: {
        padding: 24,
    },
    stepContainer: {
        gap: 20,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: Colors.text,
    },
    subtitle: {
        fontSize: 16,
        color: Colors.textSecondary,
        marginBottom: 10,
    },
    inputGroup: {
        gap: 8,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.text,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f8fafc',
        borderRadius: 15,
        paddingHorizontal: 15,
        height: 55,
        borderWidth: 1,
        borderColor: '#e2e8f0',
    },
    inputIcon: {
        marginRight: 12,
    },
    input: {
        flex: 1,
        fontSize: 16,
        color: Colors.text,
    },
    optionsGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 10,
    },
    optionCard: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 15,
        paddingVertical: 10,
        backgroundColor: '#f8fafc',
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#e2e8f0',
        gap: 8,
    },
    optionCardSelected: {
        backgroundColor: Colors.primary,
        borderColor: Colors.primary,
    },
    optionText: {
        fontSize: 14,
        color: Colors.textSecondary,
    },
    optionTextSelected: {
        color: '#fff',
        fontWeight: '600',
    },
    levelCard: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 15,
        backgroundColor: '#f8fafc',
        borderRadius: 15,
        marginBottom: 10,
        gap: 15,
        borderWidth: 1,
        borderColor: '#e2e8f0',
    },
    levelCardSelected: {
        backgroundColor: Colors.primary,
        borderColor: Colors.primary,
    },
    levelText: {
        fontSize: 16,
        color: Colors.text,
        fontWeight: '500',
    },
    levelTextSelected: {
        color: '#fff',
    },
    footer: {
        padding: 24,
        borderTopWidth: 1,
        borderTopColor: '#f1f5f9',
    },
    nextButton: {
        backgroundColor: Colors.primary,
        height: 55,
        borderRadius: 15,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 10,
    },
    disabledButton: {
        backgroundColor: '#cbd5e1',
    },
    nextButtonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
});
