import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    Image,
    TouchableOpacity,
    TextInput,
    Platform,
    ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
    Heart,
    MessageCircle,
    Send,
    Bookmark,
    Search,
    MoreHorizontal,
    PlusSquare,
    UserPlus,
    Check,
} from 'lucide-react-native';
import { Colors } from '../../constants/Colors';
import { searchUsers, Profile } from '../../lib/telegram-profiles';
import { sendClassmateRequest } from '../../lib/telegram-classmates';
import { telegram } from '../../lib/telegram';

const COMMUNITY_CHAT_ID = process.env.EXPO_PUBLIC_TELEGRAM_COMMUNITY_CHAT_ID || '-1003708310474';

export default function CommunityScreen() {
    const insets = useSafeAreaInsets();
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<Profile[]>([]);
    const [searching, setSearching] = useState(false);
    const [sentRequests, setSentRequests] = useState<Set<string>>(new Set());
    const [showingSearch, setShowingSearch] = useState(false);
    const [posts, setPosts] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchPosts = async () => {
        setLoading(true);
        try {
            const messages = await telegram.getMessages(COMMUNITY_CHAT_ID, 30);
            setPosts(messages);
        } catch (error) {
            console.error('Error fetching Telegram posts:', error);
        } finally {
            setLoading(false);
        }
    };

    React.useEffect(() => {
        fetchPosts();
    }, []);

    const handleSearch = async (query: string) => {
        setSearchQuery(query);

        if (!query.trim()) {
            setSearchResults([]);
            setShowingSearch(false);
            return;
        }

        setShowingSearch(true);
        setSearching(true);
        const results = await searchUsers(query);
        setSearchResults(results);
        setSearching(false);
    };

    const handleSendRequest = async (userId: string) => {
        const success = await sendClassmateRequest(userId);
        if (success) {
            setSentRequests(prev => new Set(prev).add(userId));
        }
    };

    const renderUser = ({ item }: { item: Profile }) => {
        const requestSent = sentRequests.has(item.id);

        return (
            <TouchableOpacity style={styles.userCard}>
                <Image
                    source={{ uri: item.avatar_url || 'https://i.pravatar.cc/150' }}
                    style={styles.userAvatar}
                />
                <View style={styles.userInfo}>
                    <Text style={styles.userName}>{item.username}</Text>
                    {item.full_name && <Text style={styles.userFullName}>{item.full_name}</Text>}
                </View>
                <TouchableOpacity
                    style={[styles.addButton, requestSent && styles.addButtonSent]}
                    onPress={() => handleSendRequest(item.id)}
                    disabled={requestSent}
                >
                    {requestSent ? (
                        <Check size={20} color="#fff" />
                    ) : (
                        <UserPlus size={20} color="#fff" />
                    )}
                </TouchableOpacity>
            </TouchableOpacity>
        );
    };

    const renderPost = ({ item }: { item: any }) => {
        const date = new Date(item.date * 1000).toLocaleDateString();
        const content = item.message || '';
        
        return (
            <View style={styles.postCard}>
                <View style={styles.postHeader}>
                    <View style={[styles.postAvatar, { backgroundColor: Colors.primary, justifyContent: 'center', alignItems: 'center' }]}>
                        <Text style={{ color: '#fff', fontWeight: 'bold' }}>C</Text>
                    </View>
                    <View style={styles.postUserInfo}>
                        <Text style={styles.postUserName}>Clevery Community</Text>
                        <Text style={styles.postUserLevel}>{date}</Text>
                    </View>
                    <TouchableOpacity>
                        <MoreHorizontal size={20} color={Colors.textSecondary} />
                    </TouchableOpacity>
                </View>

                <Text style={styles.postContent}>{content}</Text>

                {item.media && (
                    <View style={styles.postMediaPlaceholder}>
                        <Text style={styles.postMediaText}>[Media Content]</Text>
                    </View>
                )}

                <View style={styles.postActions}>
                    <View style={styles.leftActions}>
                        <TouchableOpacity style={styles.actionItem}>
                            <Heart size={22} color={Colors.text} />
                            <Text style={styles.actionText}>{item.views || 0}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.actionItem}>
                            <MessageCircle size={22} color={Colors.text} />
                            <Text style={styles.actionText}>{item.replies?.replies || 0}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.actionItem}>
                            <Send size={22} color={Colors.text} />
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity>
                        <Bookmark size={22} color={Colors.text} />
                    </TouchableOpacity>
                </View>
            </View>
        );
    };

    return (
        <View style={styles.container}>
            {/* Status Bar Protector / Airy Background */}
            <LinearGradient
                colors={['#E0F2FE', '#f8fafc']}
                style={{ height: insets.top + 60, position: 'absolute', top: 0, left: 0, right: 0, zIndex: 0 }}
            />
            <View style={{ height: insets.top, zIndex: 10 }} />

            <View style={styles.searchContainer}>
                <View style={styles.searchWrapper}>
                    <Search size={20} color={Colors.textSecondary} style={styles.searchIcon} />
                    <TextInput
                        style={styles.searchInput}
                        placeholder="Search topics, posts..."
                        value={searchQuery}
                        onChangeText={handleSearch}
                        placeholderTextColor={Colors.textSecondary}
                    />
                </View>
                <TouchableOpacity style={styles.headerAction}>
                    <PlusSquare size={24} color={Colors.text} />
                </TouchableOpacity>
            </View>

            {showingSearch ? (
                searching ? (
                    <View style={styles.centerContainer}>
                        <ActivityIndicator size="large" color={Colors.primary} />
                    </View>
                ) : searchResults.length > 0 ? (
                    <FlatList
                        data={searchResults}
                        keyExtractor={item => item.id}
                        renderItem={renderUser}
                        contentContainerStyle={styles.listContent}
                        showsVerticalScrollIndicator={false}
                    />
                ) : (
                    <View style={styles.centerContainer}>
                        <Text style={styles.emptyText}>No users found</Text>
                    </View>
                )
            ) : (
                <FlatList
                    data={posts}
                    keyExtractor={item => item.id.toString()}
                    renderItem={renderPost}
                    contentContainerStyle={styles.listContent}
                    showsVerticalScrollIndicator={false}
                    onRefresh={fetchPosts}
                    refreshing={loading}
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f8fafc',
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingBottom: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
        gap: 12,
        zIndex: 1,
    },
    searchWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        flex: 1,
        height: 48,
        borderRadius: 16,
        paddingHorizontal: 15,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
    },
    searchIcon: {
        marginRight: 10,
    },
    headerAction: {
        padding: 4,
    },
    searchInput: {
        flex: 1,
        fontSize: 16,
        color: '#1e293b',
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 40,
    },
    emptyText: {
        fontSize: 16,
        color: Colors.textSecondary,
    },
    listContent: {
        paddingVertical: 15,
    },
    userCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        padding: 15,
        marginHorizontal: 20,
        borderRadius: 16,
        marginBottom: 12,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
    },
    userAvatar: {
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: '#f1f5f9',
    },
    userInfo: {
        flex: 1,
        marginLeft: 12,
    },
    userName: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.text,
    },
    userFullName: {
        fontSize: 14,
        color: Colors.textSecondary,
        marginTop: 2,
    },
    addButton: {
        backgroundColor: Colors.primary,
        width: 40,
        height: 40,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    addButtonSent: {
        backgroundColor: '#10b981',
    },
    postCard: {
        backgroundColor: '#fff',
        marginBottom: 10,
        paddingVertical: 15,
    },
    postHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 15,
        marginBottom: 12,
    },
    postAvatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
    },
    postUserInfo: {
        flex: 1,
        marginLeft: 12,
    },
    postUserName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: Colors.text,
    },
    postUserLevel: {
        fontSize: 12,
        color: Colors.textSecondary,
    },
    postContent: {
        fontSize: 15,
        color: Colors.text,
        lineHeight: 20,
        paddingHorizontal: 15,
        marginBottom: 12,
    },
    postImage: {
        width: '100%',
        height: 300,
        marginBottom: 12,
    },
    postMediaPlaceholder: {
        height: 200,
        backgroundColor: '#f1f5f9',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 12,
        borderRadius: 12,
        marginHorizontal: 15,
        width: '92%',
    },
    postMediaText: {
        color: Colors.textSecondary,
        fontSize: 14,
    },
    postActions: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 15,
    },
    leftActions: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    actionItem: {
        flexDirection: 'row',
        alignItems: 'center',
        marginRight: 20,
    },
    actionText: {
        marginLeft: 6,
        fontSize: 14,
        fontWeight: '600',
        color: Colors.text,
    },
});
