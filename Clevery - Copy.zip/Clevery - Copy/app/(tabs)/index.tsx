import React, { useState, useRef, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    FlatList,
    KeyboardAvoidingView,
    Platform,
    Dimensions,
    ActivityIndicator,
    Keyboard,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter, useLocalSearchParams } from 'expo-router';
import {
    Send,
    Image as ImageIcon,
    Camera,
    Paperclip,
    Clock,
    Sparkles,
    Copy,
    Plus,
    X,
    Flame,
    Volume2,
    VolumeX,
    Video,
    File
} from 'lucide-react-native';
import { Colors } from '../../constants/Colors';
import * as ImagePicker from 'expo-image-picker';
import * as Clipboard from 'expo-clipboard';
import * as FileSystem from 'expo-file-system/legacy';
import * as Speech from 'expo-speech';
import Markdown from 'react-native-markdown-display';
import * as DocumentPicker from 'expo-document-picker';
import { chatWithGemini } from '../../lib/gemini';
import { chatWithGroq } from '../../lib/groq';
import { telegram } from '../../lib/telegram';

const { width } = Dimensions.get('window');

const QUICK_ACTIONS = [
    { id: 'solve', title: 'Solve homework', icon: '✍️', color: '#f59e0b' },
    { id: 'explain', title: 'Explain lesson', icon: '📚', color: '#ec4899' },
    { id: 'plan', title: 'Study plan', icon: '📅', color: '#10b981' },
    { id: 'quiz', title: 'Quiz', icon: '❓', color: '#f59e0b' },
    { id: 'flashcards', title: 'Flashcards', icon: '🖼️', color: '#8b5cf6' },
    { id: 'summary', title: 'Summarize', icon: '📋', color: '#3b82f6' },
    { id: 'essay', title: 'Essay help', icon: '📝', color: '#ef4444' },
    { id: 'notes', title: 'Study notes', icon: '📓', color: '#0d9488' },
];

export default function StudyMateScreen() {
    const insets = useSafeAreaInsets();
    const router = useRouter();
    const params = useLocalSearchParams();
    const [inputText, setInputText] = useState('');
    const [messages, setMessages] = useState<any[]>([
        {
            id: '1',
            role: 'assistant',
            content: "Hi! I'm your Study Mate 🤖 I'm here to help you with homework, explain lessons, create study plans, and more! How can I assist you today?",
            timestamp: new Date(),
        }
    ]);
    const [isLoading, setIsLoading] = useState(false);
    const [isAtBottom, setIsAtBottom] = useState(true);
    const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
    const [attachment, setAttachment] = useState<any | null>(null);
    const flatListRef = useRef<FlatList>(null);
    const inputRef = useRef<TextInput>(null);

    // Handle quick action from params
    useEffect(() => {
        if (params.action) {
            const action = QUICK_ACTIONS.find(a => a.id === params.action);
            if (action) {
                handleQuickAction(action.id);
            }
        }
    }, [params.action]);

    // Scroll tracking
    const onScroll = (event: any) => {
        const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;
        const isBottom = contentOffset.y + layoutMeasurement.height >= contentSize.height - 50;
        setIsAtBottom(isBottom);
    };

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            Speech.stop();
        };
    }, []);

    const [starCount, setStarCount] = useState(0);
    const [telegramUser, setTelegramUser] = useState<any>(null);

    useEffect(() => {
        const initUser = async () => {
            const me = await telegram.getMe();
            if (me) {
                setTelegramUser(me);
                const { getUserProfile } = await import('../../lib/supabase');
                const profile = await getUserProfile(me.id.toString());
                if (profile) {
                    setStarCount(profile.stars_tokens);
                }
            }
        };
        initUser();
    }, []);

    const sendMessage = async (text?: string) => {
        const content = text || inputText.trim();
        if (!content && !attachment || isLoading) return;

        // Star Check
        if (starCount <= 0) {
            alert("You've run out of daily stars! ⭐ Subscribe to get unlimited access or wait until tomorrow.");
            return;
        }

        // Dismiss keyboard like ChatGPT
        Keyboard.dismiss();

        let userMsgContent: any = content || "Analyze the attached file.";

        // Handle Vision Format for Images
        if (attachment && attachment.type === 'image') {
            userMsgContent = [
                { type: "text", text: content || "What is in this image?" },
                { type: "image_url", image_url: { url: `data:image/jpeg;base64,${attachment.base64}` } }
            ];
        }

        const newUserMessage = {
            id: Date.now().toString(),
            role: 'user',
            content: attachment ? (content || "Uploaded image") : content,
            aiContent: userMsgContent, // Formatted for AI
            timestamp: new Date(),
            attachmentType: attachment?.type
        };

        setMessages(prev => [...prev, newUserMessage]);
        setInputText('');
        setAttachment(null);
        setIsLoading(true);

        try {
            const systemMessage = {
                role: "system",
                content: `You are Study Mate, an expert AI tutor.
              Your goal is to provide clear, highly structured, and visually organized educational help.
              Rules:
              1. Use Bold Headers for each section.
              2. Use Bullet points (•) and Numbered lists for steps.
              3. Use always relevant Emojis (💡, ✅, ❗, 📚) to make the text engaging.
              4. Use sometimes Key Terms section for important vocabulary.
              5. Keep sentences short and clear. Avoid long blocks of text.`
            };

            const apiMessages = [
                systemMessage,
                ...messages.map(m => ({
                    role: m.role,
                    content: m.aiContent || m.content
                })),
                { role: 'user', content: userMsgContent }
            ];

            const response = await chatWithGroq(apiMessages);

            // Deduct Star on success
            const { deductStar } = await import('../../lib/supabase');
            const success = await deductStar(telegramUser.id.toString());
            if (success) setStarCount(prev => prev - 1);

            const assistantMessage = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: response,
                timestamp: new Date()
            };

            setMessages(prev => [...prev, assistantMessage]);
            scrollToEnd();
        } catch (error: any) {
            const errorMessage = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: `I'm having trouble connecting to the brain. \nError: ${error.message || 'Unknown error'} 🔄`,
                timestamp: new Date()
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    const scrollToEnd = () => {
        setTimeout(() => {
            flatListRef.current?.scrollToEnd({ animated: true });
        }, 100);
    };

    const stripMarkdown = (text: string) => {
        return text
            .replace(/[#*`~_]/g, '') // Remove markdown symbols including underscores
            .replace(/\[(.*?)\]\(.*?\)/g, '$1') // Remove links
            .replace(/([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g, '') // Remove emojis
            .replace(/\s+/g, ' ') // Collapse multiple spaces
            .trim();
    };

    const detectLanguage = (text: string) => {
        // Arabic
        if (/[\u0600-\u06FF]/.test(text)) return 'ar-SA';
        // Chinese
        if (/[\u4E00-\u9FFF]/.test(text)) return 'zh-CN';
        // Japanese
        if (/[\u3040-\u309F\u30A0-\u30FF]/.test(text)) return 'ja-JP';
        // French
        if (/[àâçéèêëîïôûùÿ]/.test(text.toLowerCase())) return 'fr-FR';
        // Spanish
        if (/[áéíóúüñ¿¡]/.test(text.toLowerCase())) return 'es-ES';
        // German
        if (/[äöüß]/.test(text.toLowerCase())) return 'de-DE';
        // Default to English
        return 'en-US';
    };

    const copyToClipboard = async (text: string) => {
        const cleanText = stripMarkdown(text);
        await Clipboard.setStringAsync(cleanText);
    };

    const toggleSpeech = async (msgId: string, text: string) => {
        if (speakingMsgId === msgId) {
            await Speech.stop();
            setSpeakingMsgId(null);
        } else {
            // Stop any current speech before starting new one
            await Speech.stop();
            setSpeakingMsgId(msgId);

            const cleanText = stripMarkdown(text);
            const language = detectLanguage(cleanText);

            Speech.speak(cleanText, {
                language: language,
                onDone: () => setSpeakingMsgId(null),
                onError: (error) => {
                    console.error('Speech error:', error);
                    setSpeakingMsgId(null);
                },
                onStopped: () => setSpeakingMsgId(null),
                pitch: 1.0,
                rate: 0.9, // Slightly slower for better comprehension
            });
        }
    };

    const handleImage = async (mode: 'camera' | 'library') => {
        let result;
        if (mode === 'camera') {
            const { status } = await ImagePicker.requestCameraPermissionsAsync();
            if (status !== 'granted') {
                alert("Sorry, we need camera permissions to make this work!");
                return;
            }
            result = await ImagePicker.launchCameraAsync({ allowsEditing: true, quality: 0.8 });
        } else {
            result = await ImagePicker.launchImageLibraryAsync({
                allowsEditing: true,
                quality: 0.8,
                mediaTypes: ['images', 'videos'] // Support videos too
            });
        }

        if (!result.canceled && result.assets[0]) {
            const asset = result.assets[0];
            const isVideo = asset.type === 'video';
            const base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: 'base64' });
            setAttachment({
                type: isVideo ? 'video' : 'image',
                uri: asset.uri,
                base64,
                mimeType: isVideo ? 'video/mp4' : 'image/jpeg'
            });
            inputRef.current?.focus();
        }
    };

    const handleDocument = async () => {
        try {
            const result = await DocumentPicker.getDocumentAsync({
                type: ['application/pdf'],
                copyToCacheDirectory: true
            });

            if (!result.canceled && result.assets[0]) {
                const asset = result.assets[0];
                const base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: 'base64' });
                setAttachment({
                    type: 'pdf',
                    uri: asset.uri,
                    base64,
                    name: asset.name,
                    mimeType: 'application/pdf'
                });
                inputRef.current?.focus();
            }
        } catch (error) {
            console.error('Document picker error:', error);
        }
    };

    const handleQuickAction = (action: string) => {
        setInputText(`${action}: `);
        inputRef.current?.focus();
    };

    const formatTime = (date: Date) => {
        return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
    };

    const renderMessage = ({ item }: { item: any }) => (
        <View style={{ marginBottom: 16 }}>
            <View style={[
                styles.messageBubble,
                item.role === 'user' ? styles.userBubble : styles.aiBubble
            ]}>
                {item.role === 'user' ? (
                    <Text style={[styles.messageText, styles.userText]}>{item.content}</Text>
                ) : (
                    <Markdown style={markdownStyles}>{item.content}</Markdown>
                )}
                {item.attachmentType && (
                    <Text style={styles.attachmentTag}>📎 {item.attachmentType === 'image' ? 'Image' : 'File'}</Text>
                )}
                <Text style={[styles.messageTime, item.role === 'user' ? styles.userTime : styles.aiTime]}>
                    {formatTime(item.timestamp || new Date())}
                </Text>
            </View>

            {item.role === 'assistant' && item.id !== '1' && (
                <View style={styles.actionButtonsContainer}>
                    <TouchableOpacity style={styles.actionButton} onPress={() => copyToClipboard(item.content)}>
                        <Copy size={14} color={Colors.primary} />
                        <Text style={styles.actionButtonText}>Copy</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.actionButton, speakingMsgId === item.id && styles.activeActionButton]}
                        onPress={() => toggleSpeech(item.id, item.content)}
                    >
                        {speakingMsgId === item.id ? (
                            <VolumeX size={14} color={Colors.error} />
                        ) : (
                            <Volume2 size={14} color={Colors.primary} />
                        )}
                        <Text style={[styles.actionButtonText, speakingMsgId === item.id && { color: Colors.error }]}>
                            {speakingMsgId === item.id ? 'Stop' : 'Speak'}
                        </Text>
                    </TouchableOpacity>
                </View>
            )}
        </View>
    );

    return (
        <View style={styles.container}>
            {/* Status Bar Protector / Airy Background */}
            <LinearGradient
                colors={['#E0F2FE', '#fff']}
                style={{ height: insets.top + 60, position: 'absolute', top: 0, left: 0, right: 0, zIndex: 0 }}
            />

            <View style={[styles.header, { paddingTop: Math.max(insets.top, 16) }]}>
                <View style={styles.headerLeft}>
                    <Text style={styles.headerTitle}>Clevery</Text>
                </View>
                <View style={styles.headerRight}>
                    <TouchableOpacity style={styles.streakBtn}>
                        <Flame size={20} color={Colors.accent} fill={Colors.accent} />
                        <Text style={styles.streakText}>12</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.starsBtn}>
                        <Text style={styles.starsText}>⭐ {starCount}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.iconOnlyBtn}>
                        <Clock size={22} color={Colors.textSecondary} />
                    </TouchableOpacity>
                </View>
            </View>

            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'padding'}
                style={{ flex: 1 }}
                keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
            >
                <FlatList
                    ref={flatListRef}
                    data={messages}
                    keyExtractor={item => item.id}
                    renderItem={renderMessage}
                    ListHeaderComponent={<WelcomeView onAction={handleQuickAction} />}
                    contentContainerStyle={styles.listContent}
                    onScroll={onScroll}
                    onContentSizeChange={() => {
                        if (isAtBottom) flatListRef.current?.scrollToEnd({ animated: true });
                    }}
                    showsVerticalScrollIndicator={false}
                    ListFooterComponent={isLoading ? (
                        <View style={styles.loadingContainer}>
                            <ActivityIndicator size="small" color={Colors.primary} />
                            <Text style={styles.loadingText}>Assistant is thinking...</Text>
                        </View>
                    ) : null}
                />

                <View style={styles.inputWrapper}>
                    {attachment && (
                        <View style={styles.attachmentPreview}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                                <ImageIcon size={14} color={Colors.primary} />
                                <Text style={styles.attachmentName} numberOfLines={1}>
                                    Image uploaded
                                </Text>
                            </View>
                            <TouchableOpacity onPress={() => setAttachment(null)} style={styles.removeAttachment}>
                                <X size={16} color="#ef4444" />
                            </TouchableOpacity>
                        </View>
                    )}
                    <View style={styles.attachmentButtons}>
                        <TouchableOpacity style={styles.attachmentButton} onPress={() => handleImage('camera')}><Camera size={20} color={Colors.primary} /></TouchableOpacity>
                        <TouchableOpacity style={styles.attachmentButton} onPress={() => handleImage('library')}><ImageIcon size={20} color={Colors.primary} /></TouchableOpacity>
                        <TouchableOpacity style={styles.attachmentButton} onPress={() => handleDocument()}><File size={20} color={Colors.primary} /></TouchableOpacity>
                    </View>

                    <View style={styles.inputContainer}>
                        <TextInput
                            ref={inputRef}
                            style={styles.input}
                            placeholder="Ask me anything..."
                            placeholderTextColor="#94a3b8"
                            value={inputText}
                            onChangeText={setInputText}
                            multiline
                        />

                        <TouchableOpacity
                            onPress={() => sendMessage()}
                            style={[styles.sendButton, (!inputText.trim() && !attachment) && styles.sendButtonDisabled]}
                            disabled={(!inputText.trim() && !attachment) || isLoading}
                        >
                            <Send size={20} color="#fff" />
                        </TouchableOpacity>
                    </View>
                </View>
            </KeyboardAvoidingView>
        </View>
    );
}

const WelcomeView = ({ onAction }: { onAction: (a: string) => void }) => (
    <View style={styles.welcomeContainer}>
        <Text style={styles.quickActionsTitle}>Quick Actions</Text>
        <View style={styles.grid}>
            {QUICK_ACTIONS.map((action) => (
                <TouchableOpacity
                    key={action.id}
                    style={[styles.gridCard, { backgroundColor: action.color + '15' }]}
                    onPress={() => onAction(action.title)}
                >
                    <Text style={styles.gridEmoji}>{action.icon}</Text>
                    <Text style={[styles.gridLabel, { color: action.color }]}>{action.title}</Text>
                </TouchableOpacity>
            ))}
        </View>
    </View>
);

const markdownStyles: any = {
    body: { color: '#1F2937', fontSize: 16, lineHeight: 24 },
    heading1: { color: Colors.primary, fontWeight: 'bold', fontSize: 20, marginVertical: 8 },
    heading2: { color: Colors.primary, fontWeight: 'bold', fontSize: 18, marginVertical: 6 },
    strong: { fontWeight: 'bold', color: '#000' },
    bullet_list: { marginVertical: 10 },
    list_item: { marginBottom: 5 },
    code_inline: { backgroundColor: '#f1f5f9', padding: 4, borderRadius: 4, color: '#e11d48' },
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#fff' },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingBottom: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
        zIndex: 1,
    },
    headerTitle: { fontSize: 26, fontWeight: '800', color: Colors.primary },
    headerLeft: { flex: 1 },
    headerRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    streakBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f8fafc',
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 20,
        gap: 4,
    },
    streakText: { fontSize: 14, fontWeight: '700', color: Colors.text },
    starsBtn: {
        backgroundColor: '#fef3c7',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
    },
    starsText: { fontSize: 13, fontWeight: '800', color: '#b45309' },
    iconOnlyBtn: { padding: 4 },
    historyBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.primary + '15',
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 20,
        gap: 5,
    },
    historyBtnText: { color: Colors.primary, fontWeight: '700', fontSize: 13 },
    listContent: { paddingHorizontal: 16, paddingBottom: 20 },
    welcomeContainer: { paddingTop: 10, marginBottom: 25 },
    quickActionsTitle: { fontSize: 16, fontWeight: '600', marginBottom: 12, color: Colors.text },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
    gridCard: { width: (width - 42) / 2, padding: 12, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
    gridEmoji: { fontSize: 24, marginBottom: 4 },
    gridLabel: { fontSize: 12, fontWeight: '600', textAlign: 'center' },
    messageBubble: { paddingHorizontal: 18, paddingVertical: 14, borderRadius: 22, marginBottom: 4 },
    userBubble: { alignSelf: 'flex-end', backgroundColor: Colors.primary, borderBottomRightRadius: 4, maxWidth: '85%' },
    aiBubble: { alignSelf: 'flex-start', backgroundColor: '#F7FAFF', borderWidth: 1.5, borderColor: '#E5E7EB', borderBottomLeftRadius: 4, width: '94%' },
    messageText: { fontSize: 16, lineHeight: 24, color: '#1F2937' },
    userText: { color: '#fff', fontWeight: '500' },
    attachmentTag: { fontSize: 12, color: Colors.textSecondary, marginTop: 5, fontStyle: 'italic' },
    messageTime: { fontSize: 10, marginTop: 8, alignSelf: 'flex-end' },
    userTime: { color: '#eee' },
    aiTime: { color: Colors.textSecondary },
    actionButtonsContainer: { flexDirection: 'row', marginLeft: 12, marginTop: 4, gap: 8 },
    actionButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', paddingVertical: 4, paddingHorizontal: 10, borderRadius: 10, borderWidth: 1, borderColor: '#E5E7EB', gap: 4 },
    actionButtonText: { fontSize: 12, color: Colors.primary, fontWeight: '600' },
    activeActionButton: {
        backgroundColor: '#fee2e2',
        borderColor: '#fecaca',
    },
    inputWrapper: {
        paddingHorizontal: 16,
        paddingTop: 8,
        paddingBottom: Platform.OS === 'ios' ? 10 : 10, // Significantly lowered
        backgroundColor: '#fff',
        borderTopWidth: 1,
        borderTopColor: '#f1f5f9',
    },
    attachmentButtons: { flexDirection: 'row', gap: 12, marginBottom: 8 },
    attachmentButton: { width: 38, height: 38, borderRadius: 19, backgroundColor: Colors.primary + '10', alignItems: 'center', justifyContent: 'center' },
    attachmentPreview: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f1f5f9', padding: 8, borderRadius: 10, marginBottom: 10, justifyContent: 'space-between' },
    attachmentName: { fontSize: 12, color: Colors.textSecondary, fontWeight: '600', flex: 1 },
    removeAttachment: { padding: 4 },
    inputContainer: { flexDirection: 'row', alignItems: 'flex-end', gap: 10 },
    input: { flex: 1, minHeight: 45, maxHeight: 120, backgroundColor: '#F3F4F6', borderRadius: 22, paddingHorizontal: 18, paddingVertical: 10, fontSize: 16, color: Colors.text },
    sendButton: { width: 45, height: 45, borderRadius: 22.5, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
    sendButtonDisabled: { backgroundColor: '#D1D5DB' },
    loadingContainer: { flexDirection: 'row', alignItems: 'center', gap: 8, marginLeft: 10, marginTop: 10, marginBottom: 20 },
    loadingText: { fontSize: 13, color: Colors.textSecondary, fontStyle: 'italic' },
});
