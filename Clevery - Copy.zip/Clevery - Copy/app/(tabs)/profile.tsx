import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Image,
    TouchableOpacity,
    Switch,
    Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import {
    Settings as SettingsIcon,
    Award,
    Flame,
    Clock,
    Grid,
    ChevronRight,
    LogOut,
    Moon,
    Globe,
    Shield,
    HelpCircle,
    Star,
    User
} from 'lucide-react-native';
import { Colors } from '../../constants/Colors';

import { telegram } from '../../lib/telegram';
import { getCurrentUserProfile } from '../../lib/telegram-profiles';
import { useRouter } from 'expo-router';

export default function ProfileScreen() {
    const insets = useSafeAreaInsets();
    const router = useRouter();
    const [isDarkMode, setIsDarkMode] = React.useState(false);
    const [userEmail, setUserEmail] = React.useState('Loading...');
    const [userName, setUserName] = React.useState('Student');
    const [avatarUrl, setAvatarUrl] = React.useState('https://ui-avatars.com/api/?name=User&background=random');

    const [starCount, setStarCount] = React.useState(0);
    const [academicLevel, setAcademicLevel] = React.useState('Student');

    React.useEffect(() => {
        const fetchProfile = async () => {
            const me = await telegram.getMe();
            if (me) {
                const { getUserProfile } = await import('../../lib/supabase');
                const profile = await getUserProfile(me.id.toString());
                if (profile) {
                    setUserName(profile.username);
                    setStarCount(profile.stars_tokens);
                    setAcademicLevel(profile.academic_level);
                    setAvatarUrl(`https://ui-avatars.com/api/?name=${profile.username}&background=random&color=fff&size=256`);
                }
            }
        };
        fetchProfile();
    }, []);

    const handleLogout = async () => {
        try {
            await telegram.logout();
            // Router will handle the redirect via _layout listener
        } catch (error: any) {
            alert('Error logging out: ' + error.message);
        }
    };

    const ACHIEVEMENTS = [
        { id: '1', emoji: '🔥', title: '7 Day', subtitle: 'Streak' },
        { id: '2', emoji: '🎯', title: 'First Focus', subtitle: 'Session' },
        { id: '3', emoji: '🤝', title: 'Community', subtitle: 'Helper' },
    ];

    const SETTINGS_OPTIONS = [
        { icon: User, label: 'Edit Profile', color: '#6366f1' },
        { icon: Globe, label: 'App Language', value: 'English', color: '#14b8a6' },
        { icon: Moon, label: 'Dark Mode', type: 'switch', color: '#8b5cf6' },
        { icon: Shield, label: 'Privacy & Security', color: '#f59e0b' },
        { icon: HelpCircle, label: 'Help & Support', color: '#64748b' },
        { icon: Star, label: 'Rate Clevery', color: '#fbbf24' },
    ];

    return (
        <View style={styles.container}>
            {/* Status Bar Protector / Airy Background */}
            <LinearGradient
                colors={['#E0F2FE', '#fff']}
                style={{ height: insets.top + 60, position: 'absolute', top: 0, left: 0, right: 0, zIndex: 0 }}
            />
            <View style={{ height: insets.top, zIndex: 10 }} />

            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                {/* Profile Header */}
                <View style={styles.profileHeader}>
                    <View style={styles.avatarContainer}>
                        <Image
                            source={{ uri: avatarUrl }}
                            style={styles.profileImage}
                        />
                    </View>
                    <Text style={styles.userName}>{userName}</Text>
                    <Text style={styles.userEmail}>{userEmail}</Text>
                    <View style={styles.levelBadge}>
                        <Text style={styles.levelText}>{academicLevel}</Text>
                    </View>
                </View>

                {/* Quick Stats */}
                <View style={styles.statsRow}>
                    <View style={styles.statItem}>
                        <Star size={20} color={Colors.accent} fill={Colors.accent} />
                        <Text style={styles.statValue}>{starCount}</Text>
                        <Text style={styles.statLabel}>Stars</Text>
                    </View>
                    <View style={styles.statDivider} />
                    <View style={styles.statItem}>
                        <Clock size={20} color={Colors.primary} />
                        <Text style={styles.statValue}>48h</Text>
                        <Text style={styles.statLabel}>Study Time</Text>
                    </View>
                    <View style={styles.statDivider} />
                    <View style={styles.statItem}>
                        <Grid size={20} color={Colors.secondary} />
                        <Text style={styles.statValue}>24</Text>
                        <Text style={styles.statLabel}>Posts</Text>
                    </View>
                </View>

                {/* Achievements */}
                <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>Recent Achievements</Text>
                        <TouchableOpacity>
                            <Text style={styles.seeAll}>See All</Text>
                        </TouchableOpacity>
                    </View>
                    <ScrollView
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={styles.achievementsScroll}
                        scrollEnabled={ACHIEVEMENTS.length > 3}
                    >
                        {ACHIEVEMENTS.map(item => (
                            <View key={item.id} style={styles.achievementCard}>
                                <Text style={styles.achievementEmoji}>{item.emoji}</Text>
                                <Text style={styles.achievementName}>{item.title}</Text>
                                <Text style={styles.achievementSubtitle}>{item.subtitle}</Text>
                            </View>
                        ))}
                    </ScrollView>
                </View>

                <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>Settings</Text>
                    </View>
                    <View style={styles.settingsList}>
                        {SETTINGS_OPTIONS.map((item, index) => (
                            <View key={index} style={[
                                styles.settingItemContainer,
                                index !== SETTINGS_OPTIONS.length - 1 && styles.settingSeparator
                            ]}>
                                <TouchableOpacity style={styles.settingItem}>
                                    <View style={[styles.settingIconContainer, { backgroundColor: item.color + '15' }]}>
                                        <item.icon size={20} color={item.color} />
                                    </View>
                                    <Text style={styles.settingLabel}>{item.label}</Text>
                                    <View style={styles.settingRight}>
                                        {item.value && <Text style={styles.settingValue}>{item.value}</Text>}
                                        {item.type === 'switch' ? (
                                            <Switch
                                                value={isDarkMode}
                                                onValueChange={setIsDarkMode}
                                                trackColor={{ false: '#e2e8f0', true: Colors.primary }}
                                                thumbColor={Platform.OS === 'ios' ? undefined : (isDarkMode ? Colors.primary : '#f4f3f4')}
                                            />
                                        ) : (
                                            <ChevronRight size={20} color={Colors.textSecondary} />
                                        )}
                                    </View>
                                </TouchableOpacity>
                            </View>
                        ))}
                    </View>
                </View>

                {/* Logout */}
                <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
                    <LogOut size={20} color={Colors.error} />
                    <Text style={styles.logoutText}>Logout</Text>
                </TouchableOpacity>

                <View style={{ height: 40 }} />
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    scrollContent: {
        paddingTop: 0,
    },
    profileHeader: {
        alignItems: 'center',
        paddingVertical: 30,
    },
    avatarContainer: {
        position: 'relative',
        marginBottom: 15,
    },
    profileImage: {
        width: 100,
        height: 100,
        borderRadius: 50,
        borderWidth: 4,
        borderColor: '#f1f5f9',
    },
    editAvatar: {
        position: 'absolute',
        right: 0,
        bottom: 0,
        backgroundColor: Colors.primary,
        padding: 8,
        borderRadius: 15,
        borderWidth: 3,
        borderColor: '#fff',
    },
    userName: {
        fontSize: 24,
        fontWeight: 'bold',
        color: Colors.text,
    },
    userEmail: {
        fontSize: 14,
        color: Colors.textSecondary,
        marginTop: 4,
    },
    levelBadge: {
        backgroundColor: Colors.primary + '15',
        paddingHorizontal: 12,
        paddingVertical: 4,
        borderRadius: 20,
        marginTop: 10,
    },
    levelText: {
        color: Colors.primary,
        fontWeight: '600',
        fontSize: 12,
    },
    statsRow: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
        backgroundColor: '#f8fafc',
        marginHorizontal: 20,
        paddingVertical: 20,
        borderRadius: 25,
        marginBottom: 30,
    },
    statItem: {
        alignItems: 'center',
    },
    statValue: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.text,
        marginTop: 4,
    },
    statLabel: {
        fontSize: 12,
        color: Colors.textSecondary,
        marginTop: 2,
    },
    statDivider: {
        width: 1,
        height: 30,
        backgroundColor: '#e2e8f0',
    },
    section: {
        paddingHorizontal: 20,
        marginBottom: 30,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    sectionTitle: {
        fontSize: 20,
        fontWeight: '500',
        color: '#1e293b',
    },
    seeAll: {
        color: Colors.primary,
        fontWeight: '600',
    },
    achievementsScroll: {
        paddingRight: 20,
    },
    achievementCard: {
        backgroundColor: '#fff',
        padding: 10,
        borderRadius: 20,
        alignItems: 'center',
        marginRight: 12,
        width: 105,
        height: 105,
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: '#f1f5f9',
    },
    achievementEmoji: {
        fontSize: 38,
        marginBottom: 8,
    },
    achievementName: {
        fontSize: 13,
        fontWeight: '700',
        color: '#1e293b',
        textAlign: 'center',
    },
    achievementSubtitle: {
        fontSize: 13,
        fontWeight: '700',
        color: '#1e293b',
        textAlign: 'center',
    },
    settingsList: {
        backgroundColor: '#fff',
        borderRadius: 25,
        paddingHorizontal: 15,
        borderWidth: 1,
        borderColor: '#f1f5f9',
    },
    settingItemContainer: {
        width: '100%',
    },
    settingSeparator: {
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
    },
    settingItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 15,
    },
    settingIconContainer: {
        width: 40,
        height: 40,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 15,
    },
    settingLabel: {
        flex: 1,
        fontSize: 16,
        fontWeight: '500',
        color: Colors.text,
    },
    settingRight: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    settingValue: {
        fontSize: 14,
        color: Colors.textSecondary,
        marginRight: 10,
    },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginHorizontal: 20,
        paddingVertical: 15,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: '#fee2e2',
    },
    logoutText: {
        color: Colors.error,
        fontWeight: 'bold',
        marginLeft: 10,
        fontSize: 16,
    },
});
