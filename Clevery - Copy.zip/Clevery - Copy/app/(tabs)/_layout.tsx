import { Tabs } from 'expo-router';
import { BotMessageSquare, BookOpenText, MessageCircleMore, Users, User } from 'lucide-react-native';

export default function TabLayout() {
    return (
        <Tabs screenOptions={{
            tabBarActiveTintColor: '#2391f0',
            tabBarInactiveTintColor: '#94a3b8',
            tabBarStyle: {
                borderTopWidth: 1,
                borderTopColor: '#f1f5f9',
                height: 60,
                paddingBottom: 10,
                paddingTop: 5,
            },
            headerShown: false,
        }}>
            <Tabs.Screen
                name="index"
                options={{
                    title: 'Study Mate',
                    tabBarIcon: ({ color }) => <BotMessageSquare size={24} color={color} />,
                }}
            />
            <Tabs.Screen
                name="space"
                options={{
                    title: 'Study Space',
                    tabBarIcon: ({ color }) => <BookOpenText size={24} color={color} />,
                }}
            />
            <Tabs.Screen
                name="messages"
                options={{
                    title: 'Messages',
                    tabBarIcon: ({ color }) => <MessageCircleMore size={24} color={color} />,
                }}
            />
            <Tabs.Screen
                name="community"
                options={{
                    title: 'Community',
                    tabBarIcon: ({ color }) => <Users size={24} color={color} />,
                }}
            />
            <Tabs.Screen
                name="profile"
                options={{
                    title: 'User',
                    tabBarIcon: ({ color }) => <User size={24} color={color} />,
                }}
            />
        </Tabs>
    );
}
