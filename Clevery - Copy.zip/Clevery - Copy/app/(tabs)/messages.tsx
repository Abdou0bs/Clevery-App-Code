import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    FlatList,
    Image,
    Platform,
    ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
    Search,
    Bell,
    Users,
    GraduationCap,
} from 'lucide-react-native';
import { Colors } from '../../constants/Colors';
import { useRouter } from 'expo-router';
import { fetchClassmates, Classmate } from '../../lib/telegram-classmates';
import { fetchUserClasses, Class } from '../../lib/telegram-classes';
import { getOrCreatePrivateChat, getClassChat } from '../../lib/telegram-chat';

export default function MessagesScreen() {
    const insets = useSafeAreaInsets();
    const router = useRouter();
    const [activeTab, setActiveTab] = useState<'classmates' | 'classes'>('classmates');
    const [searchQuery, setSearchQuery] = useState('');
    const [notificationCount, setNotificationCount] = useState(0);
    const [classmates, setClassmates] = useState<Classmate[]>([]);
    const [classes, setClasses] = useState<Class[]>([]);
    const [loading, setLoading] = useState(true);

    // Load classmates and classes
    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        setLoading(true);
        const [classmatesData, classesData] = await Promise.all([
            fetchClassmates(),
            fetchUserClasses(),
        ]);
        setClassmates(classmatesData);
        setClasses(classesData);
        setLoading(false);
    };

    const openChat = async (item: Classmate | Class, type: 'private' | 'class') => {
        let chatId: string | null = null;

        if (type === 'private') {
            const classmate = item as Classmate;
            chatId = classmate.id; // Using Telegram ID directly
        } else {
            const classItem = item as Class;
            chatId = await getClassChat(classItem.id);
        }

        if (!chatId) {
            alert('Failed to open chat');
            return;
        }

        router.push({
            pathname: `/chat/${chatId}`,
            params: {
                name: type === 'private' ? (item as Classmate).username : (item as Class).name,
                type,
                avatar: type === 'private' ? (item as Classmate).avatar_url : '',
                members: type === 'class' ? '' : ''
            }
        });
    };

    const openNotifications = () => {
        router.push('/notifications');
    };

    const renderClassmate = ({ item }: { item: Classmate }) => (
        <TouchableOpacity style={styles.chatCard} onPress={() => openChat(item, 'private')}>
            <Image
                source={{ uri: item.avatar_url || 'https://i.pravatar.cc/150' }}
                style={styles.avatar}
            />
            <View style={styles.chatInfo}>
                <Text style={styles.chatName}>{item.username || 'User'}</Text>
                <Text style={styles.chatStatus}>Available</Text>
            </View>
        </TouchableOpacity>
    );

    const renderClass = ({ item }: { item: Class }) => (
        <TouchableOpacity style={styles.chatCard} onPress={() => openChat(item, 'class')}>
            <View style={styles.classAvatar}>
                <GraduationCap size={24} color={Colors.primary} />
            </View>
            <View style={styles.chatInfo}>
                <Text style={styles.chatName}>{item.name}</Text>
                <Text style={styles.chatStatus}>{item.description || 'Class group'}</Text>
            </View>
        </TouchableOpacity>
    );

    return (
        <View style={styles.container}>
            {/* Status Bar Protector / Airy Background */}
            <LinearGradient
                colors={['#E0F2FE', '#fff']}
                style={{ height: insets.top + 60, position: 'absolute', top: 0, left: 0, right: 0, zIndex: 0 }}
            />
            <View style={{ height: insets.top, zIndex: 10 }} />

            <View style={styles.searchContainer}>
                <View style={styles.searchWrapper}>
                    <Search size={20} color={Colors.textSecondary} style={styles.searchIcon} />
                    <TextInput
                        style={styles.searchInput}
                        placeholder="Search classmates or classes..."
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                    />
                </View>
                <TouchableOpacity style={styles.notificationButton} onPress={openNotifications}>
                    <Bell size={24} color={Colors.text} />
                    {notificationCount > 0 && (
                        <View style={styles.badge}>
                            <Text style={styles.badgeText}>{notificationCount}</Text>
                        </View>
                    )}
                </TouchableOpacity>
            </View>

            {loading ? (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <ActivityIndicator size="large" color={Colors.primary} />
                </View>
            ) : (
                <FlatList
                    data={activeTab === 'classmates' ? classmates : classes as any}
                    keyExtractor={item => item.id}
                    renderItem={activeTab === 'classmates' ? renderClassmate : renderClass as any}
                    contentContainerStyle={styles.listContent}
                    ListEmptyComponent={
                        <View style={{ alignItems: 'center', marginTop: 50 }}>
                            <Text style={{ color: Colors.textSecondary, fontSize: 16 }}>
                                {activeTab === 'classmates'
                                    ? "No classmates yet. Find them in Community!"
                                    : "No classes yet. Create or join one!"}
                            </Text>
                        </View>
                    }
                    ListHeaderComponent={
                        <View style={styles.tabContainer}>
                            <TouchableOpacity
                                style={[styles.tab, activeTab === 'classmates' && styles.activeTab]}
                                onPress={() => setActiveTab('classmates')}
                            >
                                <Users size={18} color={activeTab === 'classmates' ? Colors.primary : Colors.textSecondary} />
                                <Text style={[styles.tabText, activeTab === 'classmates' && styles.activeTabText]}>Classmates</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={[styles.tab, activeTab === 'classes' && styles.activeTab]}
                                onPress={() => setActiveTab('classes')}
                            >
                                <GraduationCap size={18} color={activeTab === 'classes' ? Colors.primary : Colors.textSecondary} />
                                <Text style={[styles.tabText, activeTab === 'classes' && styles.activeTabText]}>My Classes</Text>
                            </TouchableOpacity>
                        </View>
                    }
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: Colors.text,
    },
    notificationButton: {
        backgroundColor: 'transparent',
        padding: 8,
        borderRadius: 12,
        position: 'relative',
    },
    badge: {
        position: 'absolute',
        top: -4,
        right: -4,
        backgroundColor: '#ef4444',
        borderRadius: 10,
        minWidth: 20,
        height: 20,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 2,
        borderColor: '#fff',
    },
    badgeText: {
        color: '#fff',
        fontSize: 11,
        fontWeight: 'bold',
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginHorizontal: 0,
        gap: 12,
        paddingBottom: 20,
        paddingHorizontal: 20,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
        zIndex: 1,
    },
    searchWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        flex: 1,
        height: 48,
        paddingHorizontal: 15,
        borderRadius: 16,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
    },
    searchIcon: {
        marginRight: 10,
    },
    searchInput: {
        flex: 1,
        fontSize: 16,
        color: '#1e293b',
    },
    tabContainer: {
        flexDirection: 'row',
        backgroundColor: '#f1f5f9',
        borderRadius: 12,
        padding: 4,
        marginVertical: 20,
    },
    tab: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 8,
        borderRadius: 8,
    },
    activeTab: {
        backgroundColor: '#fff',
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
    },
    tabText: {
        marginLeft: 8,
        fontSize: 14,
        fontWeight: '600',
        color: Colors.textSecondary,
    },
    activeTabText: {
        color: Colors.primary,
    },
    quickActions: {
        flexDirection: 'row',
        paddingHorizontal: 20,
        marginBottom: 20,
    },
    quickActionItem: {
        alignItems: 'center',
        marginRight: 25,
    },
    quickActionIcon: {
        width: 48,
        height: 48,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 6,
    },
    quickActionLabel: {
        fontSize: 12,
        fontWeight: '500',
        color: Colors.textSecondary,
    },
    listContent: {
        paddingHorizontal: 20,
    },
    chatCard: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
    },
    avatar: {
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: '#f1f5f9',
    },
    classAvatar: {
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: '#e0f2fe',
        justifyContent: 'center',
        alignItems: 'center',
    },
    classAvatarText: {
        fontSize: 24,
        fontWeight: 'bold',
        color: Colors.primary,
    },
    chatInfo: {
        flex: 1,
        marginLeft: 12,
    },
    chatName: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.text,
    },
    chatStatus: {
        fontSize: 13,
        color: Colors.textSecondary,
        marginTop: 2,
    },
    actionButtons: {
        flexDirection: 'row',
    },
    iconAction: {
        padding: 6,
        marginLeft: 4,
    },
});
