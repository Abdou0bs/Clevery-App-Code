import React, { useState, useEffect, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Platform,
    TextInput,
    KeyboardAvoidingView,
    Dimensions,
    Animated,
    Easing
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import {
    RotateCcw,
    Camera,
    FileText,
    MessageSquare,
    Scan,
    Timer,
    CheckCircle2,
    Circle,
    Plus,
    Flame,
    Settings as SettingsIcon,
    Play,
    Pause,
    History,
    LayoutGrid,
    Type,
    Trophy,
    Target,
    Zap,
    Clock,
    AlertCircle
} from 'lucide-react-native';
import { Colors } from '../../constants/Colors';
import * as ImagePicker from 'expo-image-picker';

const { width } = Dimensions.get('window');

const INITIAL_TASKS = [
    { id: '1', title: 'Complete Math Exercise', completed: true, category: 'Math', priority: 'high', estimate: '45' },
    { id: '2', title: 'Read Chapter 4 History', completed: false, category: 'History', priority: 'medium', estimate: '30' },
    { id: '3', title: 'Write Chemistry Report', completed: false, category: 'Chemistry', priority: 'low', estimate: '60' },
];

export default function StudySpaceScreen() {
    const insets = useSafeAreaInsets();
    const router = useRouter();
    const [tasks, setTasks] = useState(INITIAL_TASKS);
    const [timerActive, setTimerActive] = useState(false);
    const [timeLeft, setTimeLeft] = useState(1500); // 25 mins
    const [isAddingTask, setIsAddingTask] = useState(false);
    const [scannedText, setScannedText] = useState<string | null>(null);
    const [isScanning, setIsScanning] = useState(false);
    const [newTaskTitle, setNewTaskTitle] = useState('');
    const [taskPriority, setTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');
    const [taskEstimate, setTaskEstimate] = useState('15'); // mins

    // Focus Timer cleanup
    useEffect(() => {
        let interval: NodeJS.Timeout;
        if (timerActive && timeLeft > 0) {
            interval = setInterval(() => {
                setTimeLeft(prev => prev - 1);
            }, 1000);
        } else if (timeLeft === 0) {
            setTimerActive(false);
            // Focus session finished
        }
        return () => clearInterval(interval);
    }, [timerActive, timeLeft]);

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    const toggleTask = (id: string) => {
        setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
    };

    const addTask = (text?: string) => {
        const title = text || newTaskTitle;
        if (!title.trim()) return;
        const newTask = {
            id: Date.now().toString(),
            title: title,
            completed: false,
            category: 'Study',
            priority: taskPriority,
            estimate: taskEstimate
        };
        setTasks(prev => [newTask, ...prev] as any);
        setNewTaskTitle('');
        setIsAddingTask(false);
    };

    const completedCount = tasks.filter(t => t.completed).length;

    return (
        <View style={styles.container}>
            {/* Status Bar Protector */}
            <LinearGradient
                colors={['#E0F2FE', '#fff']}
                style={{ height: insets.top + 60, position: 'absolute', top: 0, left: 0, right: 0, zIndex: 0 }}
            />
            <View style={{ height: insets.top, zIndex: 10 }} />

            <ScrollView
                contentContainerStyle={[styles.scrollContent, { paddingTop: 10 }]}
                showsVerticalScrollIndicator={false}
            >
                {/* Header */}
                <View style={styles.header}>
                    <View>
                        <Text style={styles.headerSubtitle}>Good morning, Alex 👋</Text>
                    </View>
                    <TouchableOpacity style={styles.streakBadge}>
                        <Flame size={18} color={Colors.accent} fill={Colors.accent} />
                        <Text style={styles.streakText}>5 Days</Text>
                    </TouchableOpacity>
                </View>

                {/* Daily Mission - Redesigned Stars Tracker */}
                <View style={styles.section}>
                    <View style={styles.missionCard}>
                        <LinearGradient
                            colors={['#8B5CF6', '#6D28D9']}
                            style={styles.missionGradient}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 1 }}
                        >
                            <View style={styles.missionInfo}>
                                <View style={styles.missionHeader}>
                                    <Trophy size={20} color="#fff" />
                                    <Text style={styles.missionTitle}>Daily Mission</Text>
                                </View>
                                <Text style={styles.missionProgressText}>7/10 Stars Earned</Text>
                                <View style={styles.progressBarBg}>
                                    <View style={[styles.progressBarFill, { width: '70%' }]} />
                                </View>
                            </View>
                            <View style={styles.missionIcon}>
                                <Flame size={40} color="#fff" fill="#fff" opacity={0.3} />
                                <Text style={styles.missionRewardText}>+50 XP</Text>
                            </View>
                        </LinearGradient>
                    </View>
                </View>

                {/* Focus Lab - Deep Work Aesthetic */}
                <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                        <View style={styles.sectionTitleRow}>
                            <Target size={22} color="#10B981" />
                            <Text style={styles.sectionTitle}>Focus Lab</Text>
                        </View>
                        <TouchableOpacity style={styles.settingsBtn}>
                            <SettingsIcon size={20} color="#64748B" />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.focusCard}>
                        <LinearGradient
                            colors={['#ECFDF5', '#F0FDF4']}
                            style={styles.focusGradient}
                        >
                            <View style={styles.timerRing}>
                                <Text style={styles.timerText}>{formatTime(timeLeft)}</Text>
                                <Text style={styles.timerStatus}>
                                    {timerActive ? 'DEEP WORK ON' : 'READY TO FOCUS'}
                                </Text>
                            </View>

                            <View style={styles.timerControls}>
                                <TouchableOpacity
                                    style={styles.controlBtnSecondary}
                                    onPress={() => { setTimeLeft(1500); setTimerActive(false); }}
                                >
                                    <RotateCcw size={20} color="#10B981" />
                                </TouchableOpacity>

                                <TouchableOpacity
                                    style={styles.mainPlayBtn}
                                    onPress={() => setTimerActive(!timerActive)}
                                >
                                    <LinearGradient
                                        colors={timerActive ? ['#059669', '#10B981'] : ['#10B981', '#34D399']}
                                        style={styles.playGradient}
                                    >
                                        {timerActive ?
                                            <Pause size={28} color="#fff" fill="#fff" /> :
                                            <Play size={28} color="#fff" fill="#fff" style={{ marginLeft: 4 }} />
                                        }
                                    </LinearGradient>
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.controlBtnSecondary}>
                                    <Clock size={20} color="#10B981" />
                                </TouchableOpacity>
                            </View>
                        </LinearGradient>
                    </View>
                </View>

                {/* Tasks Section */}
                <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>To-Do List</Text>
                        <TouchableOpacity
                            style={styles.addButton}
                            onPress={() => setIsAddingTask(!isAddingTask)}
                        >
                            <Plus size={20} color="#fff" />
                        </TouchableOpacity>
                    </View>

                    {isAddingTask && (
                        <View style={styles.addTaskCard}>
                            <TextInput
                                style={styles.addTaskInput}
                                placeholder="Task title..."
                                value={newTaskTitle}
                                onChangeText={setNewTaskTitle}
                                autoFocus
                            />

                            <View style={styles.addTaskOptions}>
                                <View style={styles.prioritySelector}>
                                    {(['low', 'medium', 'high'] as const).map((p) => (
                                        <TouchableOpacity
                                            key={p}
                                            onPress={() => setTaskPriority(p)}
                                            style={[
                                                styles.priorityBtn,
                                                taskPriority === p && styles.priorityBtnActive,
                                                taskPriority === p && { backgroundColor: p === 'high' ? '#FEE2E2' : p === 'medium' ? '#FEF3C7' : '#DCFCE7' }
                                            ]}
                                        >
                                            <Text style={[
                                                styles.priorityBtnText,
                                                taskPriority === p && { color: p === 'high' ? '#EF4444' : p === 'medium' ? '#F59E0B' : '#10B981' }
                                            ]}>
                                                {p}
                                            </Text>
                                        </TouchableOpacity>
                                    ))}
                                </View>

                                <View style={styles.estimateInputContainer}>
                                    <Clock size={14} color="#64748B" />
                                    <TextInput
                                        style={styles.estimateInput}
                                        value={taskEstimate}
                                        onChangeText={setTaskEstimate}
                                        keyboardType="numeric"
                                        maxLength={3}
                                    />
                                    <Text style={styles.estimateUnitText}>m</Text>
                                </View>
                            </View>

                            <View style={styles.addTaskFooter}>
                                <TouchableOpacity
                                    style={styles.cancelBtn}
                                    onPress={() => setIsAddingTask(false)}
                                >
                                    <Text style={styles.cancelBtnText}>Cancel</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.confirmAddBtn} onPress={() => addTask()}>
                                    <LinearGradient
                                        colors={['#2391f0', '#1d4ed8']}
                                        style={styles.confirmGradient}
                                    >
                                        <Plus size={18} color="#fff" />
                                        <Text style={styles.confirmAddText}>Create Task</Text>
                                    </LinearGradient>
                                </TouchableOpacity>
                            </View>
                        </View>
                    )}
                    {tasks.map((task: any) => (
                        <TouchableOpacity
                            key={task.id}
                            style={styles.taskItem}
                            onPress={() => toggleTask(task.id)}
                        >
                            <View style={styles.taskInitial}>
                                <TouchableOpacity onPress={() => toggleTask(task.id)}>
                                    {task.completed ?
                                        <CheckCircle2 size={24} color="#10B981" /> :
                                        <Circle size={24} color="#CBD5E1" />
                                    }
                                </TouchableOpacity>
                            </View>

                            <View style={styles.taskBody}>
                                <Text style={[styles.taskTitle, task.completed && styles.taskCompleted]}>
                                    {task.title}
                                </Text>
                                <View style={styles.taskMeta}>
                                    <View style={[
                                        styles.priorityBadge,
                                        { backgroundColor: task.priority === 'high' ? '#FEE2E2' : task.priority === 'medium' ? '#FEF3C7' : '#DCFCE7' }
                                    ]}>
                                        <Text style={[
                                            styles.priorityText,
                                            { color: task.priority === 'high' ? '#EF4444' : task.priority === 'medium' ? '#F59E0B' : '#10B981' }
                                        ]}>
                                            {task.priority || 'medium'}
                                        </Text>
                                    </View>
                                    {task.estimate && (
                                        <View style={styles.timeBadge}>
                                            <Clock size={12} color="#64748B" />
                                            <Text style={styles.timeBadgeText}>{task.estimate}m</Text>
                                        </View>
                                    )}
                                </View>
                            </View>

                            <TouchableOpacity style={styles.taskAction}>
                                <AlertCircle size={20} color="#E2E8F0" />
                            </TouchableOpacity>
                        </TouchableOpacity>
                    ))}
                </View>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    scrollContent: {
        padding: 20,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 25,
    },
    headerSubtitle: {
        fontSize: 16,
        color: Colors.textSecondary,
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: Colors.text,
    },
    missionCard: {
        borderRadius: 24,
        overflow: 'hidden',
        elevation: 8,
        shadowColor: '#8B5CF6',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 12,
    },
    missionGradient: {
        flexDirection: 'row',
        padding: 24,
        alignItems: 'center',
    },
    missionInfo: {
        flex: 1,
    },
    missionHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        marginBottom: 8,
    },
    missionTitle: {
        fontSize: 14,
        fontWeight: '700',
        color: '#fff',
        opacity: 0.9,
        textTransform: 'uppercase',
        letterSpacing: 1,
    },
    missionProgressText: {
        fontSize: 22,
        fontWeight: '800',
        color: '#fff',
        marginBottom: 12,
    },
    progressBarBg: {
        height: 8,
        backgroundColor: 'rgba(255,255,255,0.2)',
        borderRadius: 4,
        width: '100%',
    },
    progressBarFill: {
        height: '100%',
        backgroundColor: '#fff',
        borderRadius: 4,
    },
    missionIcon: {
        alignItems: 'center',
        marginLeft: 20,
    },
    missionRewardText: {
        fontSize: 12,
        fontWeight: '700',
        color: '#fff',
        marginTop: 4,
    },
    streakBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 20,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
    },
    streakText: {
        marginLeft: 6,
        fontWeight: '700',
        color: Colors.text,
    },
    statsRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 30,
    },
    historyBtn: {
        padding: 5,
    },
    section: {
        marginBottom: 30,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    sectionTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: Colors.text,
    },
    sectionTitleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    settingsBtn: {
        padding: 4,
    },
    focusCard: {
        borderRadius: 30,
        overflow: 'hidden',
        borderWidth: 1,
        borderColor: '#DCFCE7',
    },
    focusGradient: {
        padding: 30,
        alignItems: 'center',
    },
    timerRing: {
        width: 200,
        height: 200,
        borderRadius: 100,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 4,
        shadowColor: '#10B981',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
    },
    timerText: {
        fontSize: 48,
        fontWeight: '800',
        color: '#065F46',
        fontVariant: ['tabular-nums'],
    },
    timerStatus: {
        fontSize: 10,
        fontWeight: '700',
        color: '#10B981',
        letterSpacing: 2,
        marginTop: 4,
    },
    timerControls: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 30,
        gap: 25,
    },
    mainPlayBtn: {
        width: 70,
        height: 70,
        borderRadius: 35,
        overflow: 'hidden',
        elevation: 6,
        shadowColor: '#10B981',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
    },
    playGradient: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    controlBtnSecondary: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 2,
    },
    addTaskCard: {
        backgroundColor: '#fff',
        borderRadius: 20,
        padding: 20,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#E2E8F0',
    },
    addTaskInput: {
        fontSize: 18,
        fontWeight: '600',
        color: '#1E293B',
        marginBottom: 15,
    },
    addTaskOptions: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
    },
    prioritySelector: {
        flexDirection: 'row',
        gap: 8,
    },
    priorityBtn: {
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 8,
        backgroundColor: '#F1F5F9',
    },
    priorityBtnActive: {
        elevation: 1,
    },
    priorityBtnText: {
        fontSize: 12,
        fontWeight: '700',
        color: '#64748B',
        textTransform: 'capitalize',
    },
    estimateInputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#F1F5F9',
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 8,
        gap: 4,
    },
    estimateInput: {
        fontSize: 14,
        fontWeight: '700',
        color: '#1E293B',
        width: 30,
        textAlign: 'center',
    },
    estimateUnitText: {
        fontSize: 12,
        color: '#64748B',
    },
    addTaskFooter: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
        gap: 15,
    },
    cancelBtn: {
        paddingHorizontal: 15,
    },
    cancelBtnText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#94A3B8',
    },
    confirmAddBtn: {
        borderRadius: 12,
        overflow: 'hidden',
    },
    confirmGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 15,
        paddingVertical: 10,
        gap: 6,
    },
    confirmAddText: {
        color: '#fff',
        fontWeight: '700',
        fontSize: 14,
    },
    taskItem: {
        backgroundColor: '#fff',
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        borderRadius: 20,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: '#F1F5F9',
    },
    taskInitial: {
        marginRight: 15,
    },
    taskBody: {
        flex: 1,
    },
    taskTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#1E293B',
        marginBottom: 4,
    },
    taskCompleted: {
        textDecorationLine: 'line-through',
        color: '#94A3B8',
    },
    taskMeta: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
    priorityBadge: {
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: 6,
    },
    priorityText: {
        fontSize: 10,
        fontWeight: '800',
        textTransform: 'uppercase',
    },
    timeBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    timeBadgeText: {
        fontSize: 12,
        color: '#64748B',
        fontWeight: '500',
    },
    taskAction: {
        padding: 5,
    },
    addButton: {
        backgroundColor: Colors.primary,
        padding: 8,
        borderRadius: 12,
    },
});
