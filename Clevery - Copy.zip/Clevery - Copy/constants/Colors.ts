export const Colors = {
    primary: '#2391f0', // New Blue
    secondary: '#14b8a6', // Teal
    accent: '#f59e0b', // Amber
    background: '#ffffff',
    surface: '#f8fafc',
    text: '#0f172a',
    textSecondary: '#64748b',
    border: '#e2e8f0',
    error: '#ef4444',
    success: '#22c55e',
    white: '#ffffff',
    textLight: '#94a3b8',
};

export const Gradients = {
    primary: ['#2391f0', '#60a5fa'],
    secondary: ['#14b8a6', '#0d9488'],
};
