const fs = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '../.env');
let API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY;

if (!API_KEY && fs.existsSync(envPath)) {
    const envConfig = fs.readFileSync(envPath, 'utf8');
    const match = envConfig.match(/EXPO_PUBLIC_GEMINI_API_KEY=(.*)/);
    if (match) {
        API_KEY = match[1].trim();
    }
}

if (!API_KEY) {
    console.error("No API Key found!");
    process.exit(1);
}

async function listModels() {
    const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${API_KEY}`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            console.error(`HTTP Error: ${response.status} ${response.statusText}`);
            const text = await response.text();
            console.error(text);
            return;
        }

        const data = await response.json();
        if (data.models) {
            console.log("Available Models:");
            data.models.forEach(m => {
                // Filter for generateContent supported models
                if (m.supportedGenerationMethods && m.supportedGenerationMethods.includes("generateContent")) {
                    console.log(`- ${m.name}`);
                }
            });
        } else {
            console.log("No models found in response.");
        }
    } catch (error) {
        console.error("Fetch error:", error);
    }
}

listModels();
