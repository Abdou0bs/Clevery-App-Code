import { telegram } from './telegram';

export interface Profile {
    id: string;
    username: string;
    avatar_url?: string;
    full_name?: string;
}

/**
 * Search for users by username on Telegram
 */
export async function searchUsers(query: string): Promise<Profile[]> {
    if (!query.trim()) return [];

    try {
        const result: any = await telegram.native.searchPublicChat(query);
        if (result && result['@type'] === 'chat') {
            return [{
                id: result.id.toString(),
                username: result.title || 'User',
                full_name: result.title || '',
                avatar_url: '', 
            }];
        }
        return [];
    } catch (error) {
        console.error('Error searching users on Telegram:', error);
        return [];
    }
}

/**
 * Get current user's profile from Telegram
 */
export async function getCurrentUserProfile(): Promise<Profile | null> {
    try {
        const me: any = await telegram.getMe();
        if (!me) return null;

        return {
            id: me.id.toString(),
            username: me.username || 'User',
            full_name: `${me.firstName || ''} ${me.lastName || ''}`.trim(),
            avatar_url: '',
        };
    } catch (error) {
        console.error('Error in getCurrentUserProfile:', error);
        return null;
    }
}

/**
 * Get profile by ID from Telegram
 */
export async function getProfile(id: string): Promise<Profile | null> {
    try {
        const user: any = await telegram.native.getUserProfile(id);
        if (!user) return null;

        return {
            id: user.id.toString(),
            username: user.username || 'User',
            full_name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
            avatar_url: '',
        };
    } catch (error) {
        console.error('Error fetching profile from Telegram:', error);
        return null;
    }
}

export async function updateProfile(profile: Partial<Profile>): Promise<boolean> {
    return true;
}
