export const existsSync = () => false;
export const readFileSync = () => null;
export const writeFileSync = () => {};
export const statSync = () => ({ isDirectory: () => false, size: 0 });
export const mkdirSync = () => {};
export const readdirSync = () => [];
export const promises = {
    stat: async () => ({ isDirectory: () => false, size: 0 }),
    readFile: async () => null,
    writeFile: async () => {},
    mkdir: async () => {},
    readdir: async () => [],
};
export default {
    existsSync,
    readFileSync,
    writeFileSync,
    statSync,
    mkdirSync,
    readdirSync,
    promises,
};
