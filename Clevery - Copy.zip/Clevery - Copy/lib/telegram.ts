import TdLib from 'react-native-tdlib';
import AsyncStorage from '@react-native-async-storage/async-storage';

const apiId = parseInt(process.env.EXPO_PUBLIC_TELEGRAM_API_ID || '0');
const apiHash = process.env.EXPO_PUBLIC_TELEGRAM_API_HASH || '';

export class TelegramService {
    private static instance: TelegramService;
    private isInitialized = false;

    private constructor() { }

    public static getInstance(): TelegramService {
        if (!TelegramService.instance) {
            TelegramService.instance = new TelegramService();
        }
        return TelegramService.instance;
    }

    async init() {
        if (this.isInitialized) return;
        
        try {
            await TdLib.startTdLib({
                api_id: apiId,
                api_hash: apiHash
            });
            this.isInitialized = true;
            console.log('✅ TDLib Connected Successfully');
        } catch (error) {
            console.error('❌ TDLib connection error:', error);
        }
    }

    async sendCode(phoneNumber: string) {
        await this.init();
        try {
            const cleanNumber = phoneNumber.replace(/\s+/g, '');
            await TdLib.login({
                countrycode: '',
                phoneNumber: cleanNumber
            });
            return { phoneCodeHash: '' }; // Mocking return for compatibility with existing UI
        } catch (error) {
            console.error('Error sending code:', error);
            throw error;
        }
    }

    async signIn(phoneNumber: string, phoneCodeHash: string, code: string) {
        await this.init();
        try {
            const user = await TdLib.verifyPhoneNumber(code);
            return user;
        } catch (error) {
            console.error('Error verifying code:', error);
            throw error;
        }
    }

    async joinChannel(chatIdOrUsername: string) {
        await this.init();
        try {
            // Check if it's a numeric ID (handle '-' also)
            if (/^-?\d+$/.test(chatIdOrUsername)) {
                await TdLib.joinChat(parseInt(chatIdOrUsername));
                return true;
            }
            
            // Otherwise, search for the chat first
            const chat: any = await TdLib.searchPublicChat(chatIdOrUsername);
            if (chat && chat.id) {
                await TdLib.joinChat(chat.id);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error joining chat/channel:', error);
            return false;
        }
    }

    async getMessages(chatId: string, limit: number = 30) {
        await this.init();
        try {
            // Positional arguments: (chatId: number, fromMessageId: number, limit: number, offest: number)
            const history: any = await TdLib.getChatHistory(
                parseInt(chatId),
                0,
                limit,
                0
            );
            return history || [];
        } catch (error) {
            console.error('Error getting messages:', error);
            return [];
        }
    }

    async sendMessage(chatId: string, text: string) {
        await this.init();
        try {
            return await TdLib.sendMessage({
                chatId: parseInt(chatId),
                text
            });
        } catch (error) {
            console.error('Error sending message:', error);
            return null;
        }
    }

    async getMe() {
        await this.init();
        try {
            return await TdLib.getProfile();
        } catch (error) {
            console.error('Error getting me:', error);
            return null;
        }
    }

    async logout() {
        try {
            await TdLib.logout();
            this.isInitialized = false;
        } catch (e) {
            console.error(e);
        }
    }

    async isAuthenticated() {
        try {
            await this.init();
            const state: any = await TdLib.getAuthorizationState();
            return state?.['@type'] === 'authorizationStateReady';
        } catch (e) {
            return false;
        }
    }

    get native() {
        return TdLib;
    }
}

export const telegram = TelegramService.getInstance();