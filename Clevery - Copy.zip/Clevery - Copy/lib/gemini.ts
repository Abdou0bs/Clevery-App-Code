import { GoogleGenerativeAI } from "@google/generative-ai";

const API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY || '';
const genAI = new GoogleGenerativeAI(API_KEY);

/**
 * Chat with Gemini 3 Flash
 * Supports multimodal inputs (base64 images, videos, audio)
 */
export async function chatWithGemini(messages: any[], attachment?: { type: string, base64: string, mimeType: string }) {
    try {
        const model = genAI.getGenerativeModel({
            model: "gemini-3-flash-preview", // Using Gemini 3 Flash Preview as requested
        });

        // Convert messages to Gemini format
        // Note: For a true chat, we'd use startChat, but for a simple "one-off" with context:
        const prompt = messages[messages.length - 1].content;
        const history = messages.slice(0, -1).map(m => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }],
        }));

        const chat = model.startChat({
            history: history,
            generationConfig: {
                maxOutputTokens: 2048,
            },
        });

        let result;
        if (attachment) {
            const part = {
                inlineData: {
                    data: attachment.base64,
                    mimeType: attachment.mimeType
                }
            };
            result = await chat.sendMessage([prompt, part]);
        } else {
            result = await chat.sendMessage(prompt);
        }

        const response = await result.response;
        return response.text();
    } catch (error) {
        console.error('Gemini API Error:', error);
        throw error;
    }
}
