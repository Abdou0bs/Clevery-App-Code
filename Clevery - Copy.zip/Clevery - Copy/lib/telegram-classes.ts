import { telegram } from './telegram';

export interface Class {
    id: string;
    name: string;
    description?: string;
    avatar_url?: string;
    created_by: string;
    created_at: string;
    member_count?: number;
}

export interface ClassInvite {
    id: string;
    class_id: string;
    user_id: string;
    invited_by: string;
    status: 'pending' | 'accepted' | 'rejected';
    created_at: string;
    class?: Class;
    inviter?: {
        id: string;
        username: string;
    };
}

/**
 * Fetch user's classes from Telegram groups/channels
 */
export async function fetchUserClasses(): Promise<Class[]> {
    try {
        const chats: any = await telegram.native.td_json_client_execute({
            '@type': 'getChats',
            offset_order: '9223372036854775807',
            offset_chat_id: 0,
            limit: 20
        });

        if (!chats || !chats.chat_ids) return [];

        const chatDetails = await Promise.all(
            chats.chat_ids.map((id: number) => telegram.native.getChat(id))
        );
        
        // Filter groups and channels that are considered "Classes"
        return chatDetails
            .filter(d => (d.type?.['@type'] === 'chatTypeBasicGroup' || d.type?.['@type'] === 'chatTypeSupergroup') && d.id)
            .map(d => ({
                id: d.id!.toString(),
                name: d.title || 'Unknown Class',
                description: '',
                created_by: '',
                created_at: new Date().toISOString(),
                member_count: d.positions?.[0]?.order ? 0 : 0, 
            }));
    } catch (error) {
        console.error('Error fetching Telegram classes:', error);
        return [];
    }
}

/**
 * Fetch pending class invites
 */
export async function fetchClassInvites(): Promise<ClassInvite[]> {
    return [];
}

/**
 * Accept a class invite
 */
export async function acceptClassInvite(inviteLink: string): Promise<boolean> {
    try {
        await telegram.native.td_json_client_send({
            '@type': 'joinChatByInviteLink',
            invite_link: inviteLink
        });
        return true;
    } catch (error) {
        console.error('Error accepting class invite:', error);
        return false;
    }
}

/**
 * Reject a class invite (Just ignore it)
 */
export async function rejectClassInvite(inviteId: string): Promise<boolean> {
    return true;
}

/**
 * Create a new class as a Telegram Group
 */
export async function createClass(name: string, description?: string): Promise<Class | null> {
    try {
        // Create a new group (Chat)
        const result: any = await telegram.native.td_json_client_execute({
            '@type': 'createNewBasicGroupChat',
            user_ids: [],
            title: name
        });

        if (!result || !result.id) return null;

        return {
            id: result.id.toString(),
            name,
            description,
            created_by: 'me',
            created_at: new Date().toISOString(),
        };
    } catch (error) {
        console.error('Error creating Telegram class:', error);
        return null;
    }
}
