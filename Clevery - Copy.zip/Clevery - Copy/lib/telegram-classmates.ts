import { telegram } from './telegram';

export interface Classmate {
    id: string;
    username: string;
    avatar_url?: string;
    full_name?: string;
    status: 'pending' | 'accepted' | 'rejected';
}

/**
 * Fetch user's classmates (Telegram contacts)
 */
export async function fetchClassmates(): Promise<Classmate[]> {
    try {
        // TdLib doesn't have a direct High-level getContacts but we can use Base API or search
        const result: any = await telegram.native.td_json_client_execute({
            '@type': 'getContacts'
        });

        if (!result || !result.user_ids) return [];

        const users = await Promise.all(
            result.user_ids.map((id: number) => telegram.native.getUserProfile(id.toString()))
        );

        return users.map((user: any) => ({
            id: user.id.toString(),
            username: user.username || 'User',
            full_name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
            avatar_url: '',
            status: 'accepted'
        }));
    } catch (error) {
        console.error('Error fetching Telegram contacts:', error);
        return [];
    }
}

/**
 * Fetch pending classmate requests
 */
export async function fetchClassmateRequests(): Promise<Classmate[]> {
    return [];
}

/**
 * Send a classmate request (Invite on Telegram)
 */
export async function sendClassmateRequest(phoneNumber: string): Promise<boolean> {
    return true;
}

export async function acceptClassmateRequest(requestId: string): Promise<boolean> {
    return true;
}

export async function rejectClassmateRequest(requestId: string): Promise<boolean> {
    return true;
}
