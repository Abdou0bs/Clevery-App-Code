import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface UserProfile {
    id: string; // Telegram ID
    username: string;
    country: string;
    language: string;
    academic_level: string;
    stars_tokens: number;
    credits: number;
    ai_chat_settings?: any;
    extra_data?: any;
    created_at: string;
    last_login: string;
}

export async function getUserProfile(userId: string): Promise<UserProfile | null> {
    const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

    if (error) return null;
    return data;
}

export async function updateUserProfile(userId: string, profile: Partial<UserProfile>) {
    const { error } = await supabase
        .from('profiles')
        .upsert({ id: userId, ...profile, updated_at: new Date().toISOString() });

    if (error) throw error;
}

/**
 * Grant 5 free stars daily (non-cumulative)
 * This calls our RPC function in Supabase
 */
export async function grantDailyStars(userId: string) {
    const { error } = await supabase.rpc('grant_daily_stars', { user_id_p: userId });
    if (error) console.error('Error granting daily stars:', error);
}

/**
 * Deduct one star for AI message
 */
export async function deductStar(userId: string): Promise<boolean> {
    const { data: profile, error: fetchError } = await supabase
        .from('profiles')
        .select('stars_tokens')
        .eq('id', userId)
        .single();
    
    if (fetchError || !profile) return false;
    if (profile.stars_tokens <= 0) return false;

    const { error: updateError } = await supabase
        .from('profiles')
        .update({ stars_tokens: profile.stars_tokens - 1 })
        .eq('id', userId);

    return !updateError;
}
