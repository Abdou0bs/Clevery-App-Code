import { telegram } from './telegram';

export interface Message {
    id: string;
    chat_id: string;
    sender_id: string;
    content: string;
    is_ai: boolean;
    attachment_url?: string;
    attachment_type?: string;
    created_at: string;
    sender?: {
        id: string;
        username: string;
        avatar_url?: string;
    };
}

export interface Chat {
    id: string;
    type: 'private' | 'class';
    class_id?: string;
    created_at: string;
}

/**
 * Fetch messages for a specific chat
 */
export async function fetchMessages(chatId: string): Promise<Message[]> {
    try {
        const messages: any[] = await telegram.getMessages(chatId, 50);
        
        return messages.map(m => ({
            id: m.id.toString(),
            chat_id: chatId,
            sender_id: m.sender_id?.user_id?.toString() || m.sender_id?.chat_id?.toString() || '',
            content: m.content?.text?.text || '',
            is_ai: false,
            created_at: new Date(m.date * 1000).toISOString(),
            sender: {
                id: m.sender_id?.user_id?.toString() || '',
                username: 'User',
            }
        }));
    } catch (error) {
        console.error('Error fetching Telegram messages:', error);
        return [];
    }
}

/**
 * Send a new message
 */
export async function sendMessage(
    chatId: string,
    content: string,
    attachmentUrl?: string,
    attachmentType?: string,
    isAI: boolean = false
): Promise<Message | null> {
    try {
        const result: any = await telegram.sendMessage(chatId, content);
        
        if (!result) return null;

        return {
            id: result.id.toString(),
            chat_id: chatId,
            sender_id: result.sender_id?.user_id?.toString() || '',
            content: content,
            is_ai: isAI,
            created_at: new Date(result.date * 1000).toISOString(),
            sender: {
                id: result.sender_id?.user_id?.toString() || '',
                username: 'Me',
            }
        };
    } catch (error) {
        console.error('Error sending Telegram message:', error);
        return null;
    }
}

/**
 * Subscribe to real-time messages for a chat
 */
export function subscribeToMessages(
    chatId: string,
    onNewMessage: (message: Message) => void
) {
    // TdLib bridge doesn't expose event handlers directly as EventEmitter but as global listeners or polling.
    // For now, let's keep it as an empty sub or implement polling/global listener if needed.
    return {
        unsubscribe: () => {}
    };
}

/**
 * Mark messages as read
 */
export async function markAsRead(chatId: string): Promise<void> {
    try {
        await telegram.native.td_json_client_send({
            '@type': 'viewMessages',
            chat_id: chatId,
            message_ids: [0], // Usually 0 or just viewing history
            force_read: true
        });
    } catch (error) {
        console.error('Error marking as read:', error);
    }
}

/**
 * Get or create a private chat between two users
 */
export async function getOrCreatePrivateChat(otherUserId: string): Promise<string | null> {
    try {
        const chat: any = await telegram.native.createPrivateChat(otherUserId);
        return chat?.id?.toString() || otherUserId;
    } catch (e) {
        return otherUserId;
    }
}

/**
 * Get class chat ID
 */
export async function getClassChat(classId: string): Promise<string | null> {
    return classId;
}
