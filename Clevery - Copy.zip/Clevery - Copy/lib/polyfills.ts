import 'react-native-get-random-values';
import { Buffer } from '@craftzdog/react-native-buffer';
import process from 'process';

if (typeof global.Buffer === 'undefined') {
    // @ts-ignore
    global.Buffer = Buffer as any;
}

if (typeof global.process === 'undefined') {
    // @ts-ignore
    global.process = process;
}

if (!global.process.version) {
    // @ts-ignore
    global.process.version = 'v16.13.0';
}

if (typeof global.process.nextTick === 'undefined') {
    // @ts-ignore
    global.process.nextTick = setImmediate;
}

// Ensure window and addEventListener exist for some libs that assume browser env
if (typeof window === 'undefined') {
    // @ts-ignore
    global.window = global;
}

if (typeof window.addEventListener === 'undefined') {
    // @ts-ignore
    window.addEventListener = () => {};
}

if (typeof window.removeEventListener === 'undefined') {
    // @ts-ignore
    window.removeEventListener = () => {};
}

// Ensure Buffer is also on window
if (typeof (window as any).Buffer === 'undefined') {
    (window as any).Buffer = Buffer;
}

// Net and TLS polyfills for Telegram
import net from 'react-native-tcp-socket';
// @ts-ignore
global.net = net;
// @ts-ignore
global.tls = net; // Usually it's same package or similar enough for basic calls

// Fix for setTimeout unref/ref
const originalSetTimeout = global.setTimeout;
// @ts-ignore
global.setTimeout = (fn: any, ms: any, ...args: any[]) => {
    const timer = originalSetTimeout(fn, ms, ...args);
    if (timer && typeof timer === 'object' && !timer.unref) {
        timer.unref = () => timer;
        timer.ref = () => timer;
    }
    return timer;
};
